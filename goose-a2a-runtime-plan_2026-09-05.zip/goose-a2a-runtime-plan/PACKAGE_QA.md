# 패키지 자체 검사

**검사 기준일:** 2026-09-05

## 실행한 정적 검사

| 항목 | 결과 | 범위 |
|---|---|---|
| UTF-8 Markdown 및 코드 블록 닫힘 | PASS | 모든 Markdown |
| 상대 경로 문서 링크 | PASS | 52개 링크 |
| JSON/YAML 파싱 | PASS | 모든 예제 및 호환성 기록 |
| JSON Schema 자체 유효성 | PASS | 3개 Draft 2020-12 schema |
| Role Profile 예제 검증 | PASS | VOC/로그 2개 |
| 결과 예제 스키마 검증 | PASS | 가상 결과 2개 |
| 스킬 frontmatter·이름·참조 | PASS | 4개 스킬 |
| Role의 모델·pool·MCP·출력 참조 | PASS | 예제 카탈로그 대조 |
| 출처 ID | PASS | 18개 공식 출처 항목과 본문 참조 |

## 이 검사에 포함하지 않은 것

실제 Goose 실행, SDK 설치/import, A2A/ACP 상호운용, LLM/MCP 호출, DB migration, 체크포인트 복원, 보안 침투 시험, Kubernetes 배포 및 부하 시험은 **NOT_RUN**이다. 문서 패키지의 PASS를 시스템 구현 완료나 런타임 검증 성공으로 해석하지 않는다.

`SHA256SUMS`는 이 파일을 포함한 패키지 내용의 체크섬이다. 체크섬 파일 자체는 목록에서 제외한다.
