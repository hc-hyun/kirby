# PoC용 가상 분류 참고

이 문서는 예제이며 조직 승인 품질 taxonomy가 아니다.

부품 후보 값: `display`, `battery`, `network`, `camera`, `audio`, `other`, `unknown`.

"화면이 멈춘다"는 display를 후보로 분류할 수 있지만 원인이 디스플레이 하드웨어라는 뜻은 아니다. 시스템·앱 응답 정지일 수도 있으므로 원인 단정은 금지한다.

"업데이트 후" 같은 발생 조건은 고객 보고 사실이며 인과관계가 입증되었다는 뜻은 아니다. 불명확한 입력은 unknown과 limitations로 남긴다.
