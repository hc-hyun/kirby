# 설정·스킬 예제

이 디렉터리는 **설계 계약을 구체화한 비배포용 예제**다. 이 YAML을 Goose에 직접 넘기거나 Helm values로 사용하지 않는다. 실제 실행 변환기·카탈로그·자격증명·release digest는 개발해야 한다.

## 파일

- `roles/`: VOC/로그 Role Profile, 동일 runtime model profile/pool 사용.
- `skills/`: 두 required role skill과 두 optional 전문 skill.
- `schemas/role-profile.schema.json`: 이 프로젝트의 Role 설정 검증.
- `schemas/voc-result.schema.json`, `schemas/log-result.schema.json`: PoC 결과 계약.
- `inputs/`: 두 역할의 smoke test용 가상 입력.
- `results/`: 결과 schema 검사용 가상 데이터. 실제 모델의 고정된 정답 출력은 아니다.
- `catalogs.example.yaml`: 논리 ID를 로컬 예제 경로에 연결. 실제 URL·secret 없음.

## 운영 전 반드시 구현할 검증

Role Schema 검증 외에도 스킬 중복·존재·id/version/digest, output schema 참조, MCP allowlist, pool/model 호환성, 파일 경로·크기·압축 안전성, required instruction budget을 확인해야 한다.

`max_model_requests`, `max_output_tokens` 등은 강제 경로를 구현·검증해야 제한으로 유효하다. 예제 값만 존재한다고 자동 집행되지 않는다.

품질 분류 예시는 합성 데이터이며 현업이 승인한 taxonomy/정상동작 기준이 아니다. 실제 서비스에서는 도메인 담당자의 승인된 지식·평가셋으로 교체한다.
