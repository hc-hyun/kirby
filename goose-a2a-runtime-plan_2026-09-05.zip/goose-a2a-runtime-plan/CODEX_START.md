# Codex 실행·재개 프롬프트

## 첫 실행 프롬프트

아래를 현재 작업 저장소에서 Codex에 전달한다. 아직 코드가 없다면 이 문서 패키지를 프로젝트의 초기 문서로 사용한다.

```text
이 저장소의 Goose A2A Runtime 프로젝트를 이어서 개발해줘.

먼저 기존 파일, git status, 유효한 AGENTS.md를 확인하고 사용자 변경을 보존해.
README.md, STATUS.md, docs/01_PROJECT_PLAN.md,
docs/09_COMPATIBILITY_SPIKE.md, docs/07_IMPLEMENTATION_BACKLOG.md를 읽어.

목표는 공통 Goose 하네스에 세션 생성 시 역할·스킬 버전을 바인딩하고,
A2A로 서빙하며, 나중에 분리된 API/Worker를 Kubernetes에서 확장하는 시스템이다.
Goose 포크나 새로운 LLM 추론 루프를 만들지 마.

이번 작업은 B00과 M0의 S01~S08부터 시작해.
설치된 실제 Goose와 공식 A2A/ACP SDK의 버전·API·capability를 검증해.
특히 서로 다른 HOME/작업 디렉터리의 격리, 스킬 제한,
취소, 체크포인트와 새 프로세스 복원을 우선 확인해.
A2A는 1.0 계열을 목표로 하되 정확한 SDK와 wire schema를 확인하고 고정해.
0.3 예제의 필드나 메서드를 무심코 복사하지 마.

외부 자격증명·Goose binary·Kubernetes가 없으면 그 항목은 NOT_RUN 또는 BLOCKED로 기록하고,
로컬에서 실행 가능한 fake backend 계약 테스트와 Python/uv 프로젝트 뼈대를 만들어.
이미 지원되는 것처럼 가짜 성공 결과를 만들지 마.

M0 근거가 확보되면 B01~B04의 최소 수직 기능부터 진행해.
모든 것을 한 번에 만들지 말고, 완료한 작업과 테스트 결과를 STATUS.md에 기록해.
기존 설계를 반복해서 설명하는 데 그치지 말고, 가능한 범위의 실제 파일과 테스트를 작성해.
운영망 배포, DB 파괴적 변경, 유료 API 대량 호출은 하지 마.
```

## 다음 세션에서 이어서 진행

```text
AGENTS.md와 STATUS.md를 읽고 Goose A2A Runtime 개발을 이어가줘.
이전 미완료 작업의 코드와 테스트를 먼저 확인하고,
docs/07_IMPLEMENTATION_BACKLOG.md에서 선행 조건이 충족된 다음 작업 하나를 진행해.
문서의 구현 예정 항목을 구현 완료로 오해하지 마.
각 단계가 끝나면 실제 실행한 테스트, 미검증 제약, 다음 작업 ID를 STATUS.md에 남겨.
```

## 배포 전 검증 세션

```text
기능을 추가하지 말고 docs/08_TEST_AND_RELEASE_GATES.md에 따라
현재 구현이 M2 또는 M3 출시 조건을 충족하는지 검증해.
특히 사용자 간 유출, 중복 Task, lease 만료, API 재시작, Worker 강제 종료,
취소 경합, 스킬 업데이트 후 구세션 고정, LLM 포화 시 제한을 확인해.
문서상 기능과 실행으로 검증된 기능을 구분해 결과를 보고해.
```

## 인계 기록 예시

```text
작업: B05 — PostgreSQL Task 저장 및 중복 방지
상태: DONE / IN_PROGRESS / BLOCKED 중 하나
변경: ...
실행 명령: ...
결과: PASS / FAIL / NOT_RUN
근거 파일: ...
남은 제약: ...
다음 작업: B06
```

이 프롬프트는 작업 지시문이다. 현재 프로젝트에 이미 해당 명령·테스트·서버가 구현돼 있다는 뜻이 아니다.
