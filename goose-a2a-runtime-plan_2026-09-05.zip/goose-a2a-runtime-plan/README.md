# Goose A2A Runtime — Codex 개발 인계 패키지

**문서 버전:** 1.0 · **작성일:** 2026-09-05 · **상태:** 설계 및 개발 계획 / 구현 시작 전

> 공통 Goose 하네스에 역할별 스킬을 주입하고, A2A로 제공하며, Kubernetes에서 사용자와 실행 상태를 격리하는 서빙 시스템을 만든다.

## 먼저 알아둘 것

이 패키지는 **계획서·작업 지침·설정 예제**다. 실행 가능한 서버, 검증을 마친 Goose 연동 코드, 설치 완료된 Helm 차트는 포함하지 않는다. 라이브 Goose·LLM·Kubernetes를 이용한 테스트는 수행하지 않았다. 예제 YAML은 이 프로젝트의 제안 스키마이며 Goose의 공식 설정 파일이 아니다.

핵심 결정은 **세션 생성 시 스킬 집합과 버전을 고정하고, 선택 스킬 본문은 필요할 때 읽는 방식**이다. 역할마다 새 에이전트 코드를 만들지 않는다. 하지만 여러 사용자가 하나의 Goose 프로세스·HOME·세션 DB를 공유하도록 만들지도 않는다.

## Codex에서 시작하는 방법

1. 새 작업 디렉터리에 이 압축을 푼다. 기존 저장소에서 시작한다면 먼저 `git status`와 기존 `AGENTS.md`를 확인하고, 파일을 무조건 덮어쓰지 않는다.
2. [CODEX_START.md](CODEX_START.md)의 **첫 실행 프롬프트**를 전달한다.
3. Codex는 [AGENTS.md](AGENTS.md), [프로젝트 계획](docs/01_PROJECT_PLAN.md), [호환성 검증](docs/09_COMPATIBILITY_SPIKE.md)을 먼저 읽고, 백로그의 선행 검증부터 진행한다.
4. 구현·검증 결과는 [STATUS.md](STATUS.md)와 호환성 매트릭스에 누적한다. 후속 세션은 여기서 재개한다.

기존 저장소에 문서만 옮길 때는 루트 `AGENTS.md`의 유효 범위를 확인한다. 하위 문서 디렉터리에 넣은 지침이 다른 코드 디렉터리에 자동 적용된다고 가정하지 않는다.

## 핵심 문서

| 파일 | 목적 |
|---|---|
| [AGENTS.md](AGENTS.md) | 구현 원칙, 금지사항, 테스트와 인계 규칙 |
| [CODEX_START.md](CODEX_START.md) | 첫 작업·후속 작업용 프롬프트 |
| [STATUS.md](STATUS.md) | 완료 여부와 다음 작업의 단일 기록 |
| [01_PROJECT_PLAN.md](docs/01_PROJECT_PLAN.md) | 목표, 범위, 스택, 단계별 출시 기준 |
| [02_ARCHITECTURE.md](docs/02_ARCHITECTURE.md) | API/Worker 분리와 실행 흐름 |
| [03_SKILL_AND_ROLE_POLICY.md](docs/03_SKILL_AND_ROLE_POLICY.md) | 정적·동적 주입, 버전, 권한, 예제 계약 |
| [04_A2A_ACP_CONTRACT.md](docs/04_A2A_ACP_CONTRACT.md) | A2A/ACP 매핑, 상태, 스트리밍, 취소 |
| [05_DATA_AND_RECOVERY.md](docs/05_DATA_AND_RECOVERY.md) | 데이터 모델, 실행권, 중복 방지, 체크포인트 |
| [06_SECURITY_AND_KUBERNETES.md](docs/06_SECURITY_AND_KUBERNETES.md) | 사용자 격리, 도구 권한, 배포·확장 |
| [07_IMPLEMENTATION_BACKLOG.md](docs/07_IMPLEMENTATION_BACKLOG.md) | 의존성과 완료 조건이 있는 작업 목록 |
| [08_TEST_AND_RELEASE_GATES.md](docs/08_TEST_AND_RELEASE_GATES.md) | 필수 테스트와 출시 차단 조건 |
| [09_COMPATIBILITY_SPIKE.md](docs/09_COMPATIBILITY_SPIKE.md) | 추측하면 안 되는 외부 기능 검증 |
| [10_OPERATIONS_RUNBOOK.md](docs/10_OPERATIONS_RUNBOOK.md) | 장애·배포·롤백·권한 회수 대응 |
| [11_DECISION_LOG.md](docs/11_DECISION_LOG.md) | 설계 결정 및 변경 절차 |
| [SOURCES.md](docs/SOURCES.md) | 공식 출처와 검증 범위 |

`examples/`에는 VOC·로그 역할 설정, 공통 카탈로그, 네 개의 스킬, 결과·역할 JSON Schema가 있다. 도메인 분류 체계와 예제 데이터는 **PoC용 가상 예시**다. 현업이 승인한 품질 기준으로 사용하지 않는다.

## 완료의 의미

- **M0:** 실제 Goose/SDK 조합과 격리·복원 경계를 확인했다.
- **M1:** 단일 사용자에서 실제 A2A → Goose → 결과 흐름이 동작한다.
- **M2:** 분리된 API/Worker가 다중 사용자, 영속화, 재연결, 장애 시험을 통과한다.
- **M3:** Kubernetes에서 확장·축소·권한·부하 기준을 통과한 제한된 읽기 전용 서비스다.
- **M4:** 양방향 A2A 호출, 쓰기 승인, 코드 실행 등 후속 범위다.

M1 결과를 대량 사용자용 프로덕션 서비스로 소개하지 않는다. M0 검증이 막혀도 fake backend 기반 계약 테스트는 계속 만들 수 있지만, 미검증 기능을 지원한다고 표시해서는 안 된다.
