# 06. 보안 · Kubernetes · 용량 관리

## 1. 신뢰 경계

사용자 프롬프트, 첨부 파일, 검색 결과, MCP 결과, 공개 스킬 저장소는 신뢰할 수 없는 입력이다. 운영자가 검증한 Role/Skill 번들도 코드와 마찬가지로 검토·해시·배포 이력이 필요하다.

권한은 프롬프트가 아니라 실행 경계에서 제한한다. 기본 Worker는 **읽기 전용 MCP + 제한된 파일 읽기**이며 임의 Shell, 코드 실행, 패키지 설치, 외부 URL 스킬 설치, Goose config 변경을 허용하지 않는다.

## 2. 사용자와 도구 권한

OIDC 검증에서 issuer, audience, signature, expiry, 허용 알고리즘과 claim mapping을 확인한다. 권한 범위는 서버가 검증한 identity에서 계산한다. A2A 본문 또는 사용자 정의 header를 그대로 신뢰하지 않는다.

초기 Context는 생성한 subject/client의 소유다. 다른 사용자의 Task ID, contextId, artifactId를 알아도 조회·구독·취소·다운로드를 허용하지 않는다. 공유 기능은 명시적 ACL을 추가한 후 제공한다.

MCP/LLM에는 각 대상에 적합한 자격증명을 사용한다. 무조건적인 사용자 토큰 전달은 금지한다. MCP의 보안 지침도 토큰 passthrough를 위험한 방식으로 다룬다. [SRC-15]

사내 인증 서버가 token exchange를 지원한다고 가정하지 않는다. 대안은 승인된 service credential과 서버 측 사용자 범위 검사다. 공유 credential을 쓰는 경우에도 DB/RAG가 해당 사용자의 허용 데이터를 넘지 않게 강제해야 한다. 이 경계가 준비되지 않으면 데이터 접근 범위를 제한한 pilot만 운영한다.

## 3. 파일·네트워크·자식 프로세스

- 모든 실행은 새 작업 디렉터리, 분리 HOME/XDG, 제한된 환경변수 allowlist로 시작한다.
- 컨테이너에 hostPath, Docker socket, privileged, hostNetwork를 주지 않는다.
- worker service account의 API 권한은 최소화하고 필요 없으면 토큰 자동 마운트를 끈다.
- root filesystem과 스킬 경로는 읽기 전용으로 두고 작업·임시 경로만 writable로 둔다.
- capabilities drop, non-root, seccomp 기본 정책, PID/CPU/memory/ephemeral storage 제한을 적용한다.
- ACP terminal/file callback과 Goose 자체 built-in tool을 **둘 다** 검사한다. client capability를 껐다고 agent의 모든 로컬 실행이 차단됐다고 가정하지 않는다.
- 프로세스 종료 시 Goose와 생성된 자식 프로세스 그룹을 정리하고 reap한다.
- cloud metadata IP, 내부 관리망, 임의 외부 URL에 대한 egress를 차단한다. 승인된 MCP/LLM/DB/Object Storage/DNS만 연결한다.
- MCP Roots는 도구의 힌트가 될 수 있지만 OS sandbox나 DB 권한의 대체물이 아니다.

순수 Kubernetes NetworkPolicy가 모든 FQDN 정책을 제공한다고 가정하지 않는다. 현재 CNI의 실제 기능과 egress gateway를 확인해 배포한다.

## 4. 로그와 결과

일반 운영 로그는 task/attempt/role/pool/trace ID, latency, 안전한 error code 중심으로 구성한다. 원문 VOC, 프롬프트, full tool result, 모델 reasoning, token을 기본적으로 출력하지 않는다.

Goose 자체 로그·세션 DB도 별도의 민감정보 저장소다. 플랫폼 logger만 정제했다고 끝나지 않는다. runtime 로그 설정·수집 agent exclude·보존·암호화·접근권한을 검사한다.

파일 Artifact는 승인된 bucket/key와 tenant 소유권을 확인한다. short-lived URL 또는 인증된 다운로드 endpoint를 제공하고, 임의 remote URL을 가져오거나 내부 URL을 공개하지 않는다. HTML 등 실행 가능한 내용을 다운로드할 때 content type/attachment/CSP 경계를 정한다.

## 5. Kubernetes 리소스 계획

| 리소스 | 계획 |
|---|---|
| API Deployment | M3 최소 2 replica, readiness와 DB 의존성 검사 |
| Worker Deployment | 공통 pool, Pod당 활성 Goose 1개 |
| ClusterIP Service / HTTPRoute | 기존 Envoy 연결; Goose stdio 포트는 없음 |
| ConfigMap | 비밀 없는 플랫폼 설정과 참조 |
| Secret | credential reference 대상; token 원문은 문서/ConfigMap 금지 |
| NetworkPolicy | default deny와 필요한 경로만 allow |
| ServiceAccount/RBAC | 운영에 필요한 최소 권한 |
| Migration Job | 배포당 한 번, advisory lock 등으로 중복 실행 방지 |
| KEDA ScaledObject | 검증된 pool의 workload 지표, 상한 필수 |
| PDB / topology spread | 가용성 보조; 작업 안전성의 대체물 아님 |

Object Storage는 외부 공유 저장소를 제안한다. Task용 PostgreSQL은 기존 분리 운영 DB의 용량·백업·권한·connection budget을 점검해 사용한다. LLM 추론 GPU는 Goose Worker Pod에 직접 요청하지 않는 구조가 기본이다.

## 6. probe와 drain

liveness는 프로세스가 응답 가능한지 확인하고 LLM 지연으로 재시작하지 않는다. readiness는 신규 작업 수용 가능 상태다. Worker는 drain 시작 시 claim을 중단한다.

종료 순서:

```text
SIGTERM / drain request
 → 신규 claim 중단
 → heartbeat와 현재 작업 정리 유지
 → 안전한 종료 또는 checkpoint/명시적 취소
 → Goose 및 자식 종료
 → 마지막 상태 확정 후 종료
```

`preStop`과 terminationGracePeriod는 정상 종료에 도움을 주지만 노드 소실·SIGKILL을 보장하지 않는다. PDB도 모든 직접 삭제·롤링 업데이트로부터 작업을 보호하지 않는다. 따라서 [05](05_DATA_AND_RECOVERY.md)의 복구를 별도로 구현한다. [SRC-13][SRC-14]

일반 Deployment의 scale-down이 항상 idle Worker만 골라 삭제하지는 않는다. idle-only 축소를 보장한다고 쓰지 말고 stabilization window, 제한된 축소 속도, termination 절차, read-only retry를 실제로 테스트한다. 필요해졌을 때 별도 lease-aware worker controller를 검토한다.

## 7. autoscaling과 model admission

KEDA PostgreSQL scaler를 사용하면 DB query의 수치로 replica를 조정할 수 있다. [SRC-10]

pool별 유효 backlog는 해당 pool에서 실행 가능한 QUEUED/RETRY_WAIT와 활성 slot 사용을 함께 고려한다. `WAITING_INPUT`과 다른 pool 작업, 차단된 모델의 작업을 무조건 실행 수요에 넣지 않는다. scale-down 시 실행 중 작업을 빠뜨리지 않는다.

```text
희망 실행 슬롯 = 정책상 적격 대기량 + 현재 실행량
허용 슬롯 = min(희망 슬롯, Worker 최대치, 모델별 수용 예산)
```

이는 개념식이다. HPA/KEDA metric type과 target 의미를 검증하고 이 수식을 query에 중복 적용하지 않는다. 한 Deployment를 여러 독립 controller가 서로 다른 replica 목표로 제어하지 않게 한다.

모델 slot은 **Goose Task 하나가 실행 중 가질 수 있는 모델 부담을 제한하는 보수적 수단**이다. 정확한 provider request/token budget은 별도 gateway에서 집행해야 한다. 동시 Task 수와 동시 LLM 요청 수가 항상 같지는 않다.

## 8. quota · fairness · backpressure

사용자 동시 Task·대기량, tenant 전체 slot, role별 실행 상한, model별 예산, global queue hard limit을 둔다. 동시성 quota는 DB의 원자적 예약으로 집행한다.

interactive와 batch를 별도 pool/우선순위로 나눠 batch가 실시간 대화를 잠식하지 않게 한다. tenant별 round-robin 또는 작은 fair batch claim을 사용하고, 특정 대형 tenant 하나가 모든 slot을 선점하는 테스트를 포함한다.

과부하에서는 요청을 무한히 저장하지 않는다. 명확한 busy/rate-limit 응답과 재시도 안내를 제공한다. LLM 429가 늘면 Worker 수만 늘리지 않는다.

`max_model_requests`와 `max_output_tokens`는 설정으로만 존재해서는 안 된다. Goose의 지원 설정 또는 gateway에서 강제되는지 S08에서 확인한다. hard limit을 집행할 경로가 없으면 해당 기능을 문서에서 제한으로 광고하지 않는다.

## 9. 관측 지표

| 영역 | 필요한 지표 |
|---|---|
| 접수 | request rate, rejection reason, queue age/length |
| 실행 | active tasks, start latency, Goose spawn/restore, task duration |
| 모델 | model queue/429, request latency, input/output tokens, 실패 |
| 도구 | tool duration/error, denied tool count, dependency availability |
| 영속성 | DB pool/latency, heartbeat failures, checkpoint size/time/errors |
| 상태 | cancel latency, stale lease, duplicate message, orphan artifact |
| 스트림 | connections, reconnects, lag, slow-client disconnect |
| 격리 | cross-tenant deny, secret redaction violations |

고카디널리티 task/user ID를 metrics label로 무제한 쓰지 않는다. trace/log correlation에서 제한적으로 사용한다. 실제 비용 값은 모델 가격·사내 정책이 제공됐을 때만 계산한다.

## 10. 운영 출시의 선행조건

OIDC와 MCP 권한 연결, Secret 보관, 네트워크 접근, 모델 수용량, 데이터 보존, 외부 DB backup/restore, Object Storage 복원이 확인되어야 한다. 예제 profile의 제한값을 그대로 운영 SLO로 간주하지 않는다.

참고: [런북](10_OPERATIONS_RUNBOOK.md), [출시 게이트](08_TEST_AND_RELEASE_GATES.md), [출처](SOURCES.md).
