# 11. 설계 결정 기록

초기 상태는 모두 **설계상 채택 / 실행 검증 전**이다. 결과를 바꾸면 날짜·근거·영향·migration·테스트를 기록한다.

| ADR | 결정 | 선택 이유 | 재검토 조건 |
|---|---|---|---|
| ADR-001 | Goose는 포크 없이 ACP stdio로 연결 | 하네스 재사용과 버전 경계 분리 | 공식 embedding/serving 경로가 명확한 이득 제공 |
| ADR-002 | API/Worker 분리 | HTTP 연결과 실행 생명주기 분리 | 단순화가 필요해도 논리 경계는 유지 |
| ADR-003 | Role/Skill 세션 바인딩 고정 | 재현성·권한·업데이트 일관성 | 승인된 런타임 skill 추가의 업무 필요 |
| ADR-004 | required 즉시 주입, available 지연 로딩 | 역할 누락 방지와 context 절약 | 실측 품질/토큰 결과 |
| ADR-005 | PostgreSQL 작업·이벤트 원장 | 기존 인프라 활용, 중복 상태 최소화 | 측정된 DB 병목과 전문 queue 필요 |
| ADR-006 | Object Storage 불변 checkpoint | Worker 이동·결과 보관 | 사내 S3 미제공 시 대안 검증 |
| ADR-007 | 초기 Pod당 Goose 1개 | 사용자 환경·수명 관리 단순화 | 격리 검증 후 실측 밀도 이득 |
| ADR-008 | 동일 Context 비종료 Task 1개 | 대화 상태 경쟁 제거 | 명시적 fork/merge semantics 필요 |
| ADR-009 | 읽기 전용 MCP부터 | 안전한 retry·승인 없는 초기 출시 | 영속 approval·쓰기 멱등성 준비 |
| ADR-010 | A2A 1.0 JSON-RPC 한 binding | 호환 범위·검증 비용 관리 | 실제 client가 REST/gRPC 요구 |
| ADR-011 | checkpoint는 안전한 턴 경계 | 라이브 실행 이전의 복잡성 회피 | 공식 runtime가 durable pending execution 지원 |
| ADR-012 | 코드보다 설정으로 역할 추가 | 전문 agent 반복 개발 제거 | 도구 자체 개발과 역할 코드를 혼동하지 않음 |
| ADR-013 | UI·Agent Gateway·Operator는 제외 | 기능 중복과 초기 운영 부담 감소 | 실제 정책·규모 요구 확인 |
| ADR-014 | token/권한은 스킬과 분리 | 배포물에 비밀 포함 방지 | 예외 없음; 새 위임 방식은 검증 필요 |

## 이전 논의에서 특히 명확히 한 사항

- A2A adapter가 있다고 분산 서빙이 자동으로 완성되지는 않는다.
- `goose session export`와 새 Pod에서의 import/load는 별도 검증이다.
- KEDA와 PDB가 실행 중인 작업을 무조건 보호하지 않는다.
- Skill/Profile YAML은 제안 규격이며 Goose 옵션이 아니다.
- API가 접수 직후 반환해도 되는지는 A2A 요청 mode에 달려 있다.
- Agent Card skill과 내부 Agent Skills 패키지는 다른 개념이다.
- A2A로 노출되는 방향이 MVP이며 Goose가 외부 A2A를 부르는 방향은 F01이다.

## 새 ADR 템플릿

```text
ID / 날짜 / 상태:
문제:
기존 선택:
검증한 대안:
결정과 근거:
보안·호환성·migration 영향:
필수 회귀 테스트:
변경한 문서·예제·코드:
```
