# 01. 프로젝트 계획서

**프로젝트:** goose-a2a-runtime · **버전:** 1.0 · **기준일:** 2026-09-05

## 1. 문제와 목표

업무별 에이전트를 매번 코딩하지 않고 하나의 Goose 하네스에 역할·스킬·도구 정책을 조합한다. 외부에서는 역할별 A2A 에이전트로 접근하고, 내부에서는 공통 Worker가 사용자별로 격리된 세션을 실행한다.

예를 들어 VOC 분석과 로그 분석은 서로 다른 프로그램이 아니라 동일한 실행 이미지에 대한 서로 다른 Role Profile이다. 역할의 추가·수정은 스킬/프로필 검증과 배포로 처리한다.

**하나의 하네스는 하나의 코드베이스라는 뜻이다. 모든 사용자가 한 프로세스·컨텍스트·자격증명을 공유한다는 뜻이 아니다.**

## 2. 요구사항

| ID | 요구사항 | 확인 방법 |
|---|---|---|
| R01 | Goose 추론 루프를 재사용 | 자체 LLM agent loop가 없는지 코드 리뷰 |
| R02 | 스킬 주입으로 VOC/로그 역할 전환 | 같은 이미지로 두 역할의 평가 시나리오 통과 |
| R03 | A2A 서버로 메시지·Task·진행·취소·결과 제공 | 공식 SDK client 기반 계약 테스트 |
| R04 | 사용자/테넌트/역할/세션 격리 | 교차 사용자 조회·도구·파일 접근 차단 시험 |
| R05 | 버전 고정과 재현 가능한 실행 명세 | 새 배포 이후 기존 세션의 digest 불변 |
| R06 | API와 Worker 독립 확장 | API 장애와 실행 생명주기 분리 확인 |
| R07 | Pod 교체 후 안전한 대화 재개 | 새 프로세스·새 Pod에서 체크포인트 복원 |
| R08 | 부하·비용·LLM 용량 제한 | 포화 시험에서 상한과 공정성 확인 |
| R09 | 단순한 코드와 운영 | Python/uv, 작은 모듈, 명시적 상태·SQL |
| R10 | 기존 인프라와 통합 | Envoy, 외부 DB, LLM Gateway, MCP 설정 검증 |

Goose의 ACP, Skills, 로컬 세션 저장 기능은 공식 문서에서 확인했다. 이 조합이 곧바로 분산 멀티테넌트 서비스가 된다는 뜻은 아니며, 본 프로젝트가 추가하는 부분이다. [SRC-01][SRC-02][SRC-03]

## 3. 선택한 구조

```text
A2A Client
    → 기존 Envoy Gateway
    → A2A API (인증, 역할, 요청/상태/스트림)
    → PostgreSQL (Task, 큐, 실행권, 이벤트, Context)
    → Goose Worker (ACP client → goose acp)
        → LLM Gateway / vLLM
        → 승인된 MCP
    ↔ Object Storage (스킬 번들, 체크포인트, 결과)
```

새로운 상시 서버는 API와 Worker 두 종류를 기본으로 한다. Role/Skill Registry는 처음부터 독립 서비스로 만들지 않고 Git의 소스, DB의 배포 메타데이터, Object Storage의 불변 번들로 구성한다.

## 4. 스킬 주입 결정

**세션 생성 시 동적 바인딩 + 세션 중 버전 고정 + 선택 스킬 본문 지연 로딩**을 기본값으로 한다.

| 주입 방식 | 선택 |
|---|---|
| 이미지에 스킬 포함 | 공통 bootstrap 또는 폐쇄망 최소 동작용만 |
| Pod 시작 시 역할 고정 | 특수 실행 의존성이나 별도 보안 풀에 한정 |
| 세션 생성 시 역할·스킬 결정 | 기본 방식 |
| 실행 중 파일 덮어쓰기·임의 스킬 설치 | 초기 범위 제외 |

필수 역할 지침은 시작 시 주입한다. 보조 스킬은 허용 목록을 먼저 구성한 다음 Goose의 선택 로딩에 맡긴다. 도구 접근과 실행 권한은 외부 정책으로 제한한다. 상세는 [03](03_SKILL_AND_ROLE_POLICY.md).

## 5. 개발 범위

### M0 — 가능 여부와 경계를 실제로 검증

정확한 Goose/SDK 버전 고정, ACP handshake, 스킬·도구 제한, 취소, 새 프로세스 복원, 모델 연결을 확인한다. 실행 근거 없이 통과시키지 않는다.

### M1 — 단일 사용자 최소 수직 기능

하나의 API와 Worker 동작 경로, 역할 두 개, 실제 Goose 요청, A2A 결과와 취소, read-only MCP smoke test. 로컬에서 검증 가능해야 한다. M1은 상용 다중 사용자 서비스가 아니다.

### M2 — 다중 사용자 서빙

분리 프로세스 API/Worker, PostgreSQL 작업 큐, 일관된 실행권, 사용자 경계, 이벤트 저장, API 재연결, Object Storage 체크포인트, 안전한 재시도, 취소 경합을 완성한다.

### M3 — 제한된 읽기 전용 서비스 출시

Kubernetes/Helm, OIDC 통합, 네트워크·도구 정책, scale-out/scale-in, 부하·복원·유출 시험, 운영 지표·런북을 통과한다. 실제 성능 수치는 부하 측정 보고서에서 결정한다.

### M4 — 후속 기능

Goose에서 원격 A2A 호출, 장기 승인 대기, 쓰기 작업, 임의 코드 실행용 sandbox, 역할 간 handoff, 더 높은 프로세스 밀도. 각 기능을 별도 승인·테스트 범위로 추가한다.

## 6. 하지 않을 것

Goose 포크, 자체 추론 루프, 모든 A2A transport 동시 지원, 공개 스킬 마켓, 임의 원격 스킬 설치, Operator/CRD, 자체 메시지 브로커, 다중 하네스 범용 추상화, 무중단 LLM 실행 이동, 외부 부작용의 exactly-once 보장은 초기 목표가 아니다.

초기 A2A는 **공식 1.0 계열 SDK의 JSON-RPC 한 가지 binding**을 선택한다. 구체적 wire field·method·enum은 선택한 SDK를 기준으로 검증한다. 이전 0.3 예제와 혼합하지 않는다. [SRC-06]

## 7. 기술 선택안

다음은 프로젝트의 선택안이다. 정확한 의존성 버전은 M0에서 결정하고 `uv.lock`과 image digest로 고정한다.

| 영역 | 기본 선택 | 비고 |
|---|---|---|
| 애플리케이션 | Python 3.12를 초기 후보로, uv | 사내 base image와 SDK 교집합 검증 |
| A2A | 공식 `a2a-sdk` HTTP server 통합 | 모델·직렬화 재사용; 서버 확장점 확인 |
| ACP | 공식 `agent-client-protocol` | stdio client, capability 검증 |
| HTTP 운영 endpoint | FastAPI/Starlette | A2A 서버 통합과 중복 라우팅 피함 |
| 데이터 검증 | Pydantic / JSON Schema | 내부 DTO와 예제 계약 검증 |
| PostgreSQL | psycopg 3 async pool, 명시적 SQL | migration은 번호 있는 SQL + 단일 migration job |
| Object Storage | S3 API + boto3 | blocking I/O는 event loop 밖에서 실행 |
| 테스트 | pytest, pytest-asyncio, HTTPX | fake ACP/MCP/LLM 경계 포함 |
| 코드 품질 | Ruff | 과도한 도구 추가 지양 |
| 배포 | Docker/OCI + Helm | Goose 공식 이미지 또는 검증한 바이너리 포함 |
| 자동 확장 | KEDA PostgreSQL scaler | 설치된 Kubernetes/KEDA 버전과 검증 [SRC-10] |
| 지표 | Prometheus / OpenTelemetry 선택 통합 | 본문·토큰·PII 수집은 최소화 |

표의 라이브러리는 선정안이지 설치·연동을 마쳤다는 주장이 아니다. A2A와 ACP SDK의 역할은 공식 문서에 근거한다. [SRC-06][SRC-07]

## 8. 인프라 가정과 미확정 사항

사용자가 설명한 Kubernetes, 기존 Envoy, 외부 PostgreSQL, LLM Gateway/vLLM, MCP 연결을 활용한다. 실제 endpoint·버전·토큰을 이 문서에서 추정하지 않는다.

Object Storage는 S3 호환 저장소를 제안한다. 현재 파일 서버/NFS가 있다는 사실만으로 S3 API가 있다고 간주하지 않는다. 미구축 상태라면 로컬 파일 저장소는 개발용으로만 사용하고 공유 서비스 출시 전 영속 저장 경로를 결정한다.

사용자 수, 피크 도착률, 평균/상위 지연, GPU 처리량, 데이터 보존 정책은 아직 실측·합의 전이다. 문서의 자원·시간 상한은 예시 또는 초기 조정값으로 구분한다.

## 9. 성능 산정 원칙

등록 사용자 수와 동시 실행 수를 구분한다. 평균 실행 수는 대략 도착률 × 평균 실행 시간으로 추정하고, burst·상위 지연·LLM 처리량을 따로 측정한다.

예: 초당 5개 × 평균 20초 = 평균 100개 실행 슬롯. 30% 여유를 임의로 더하면 130개다. **이는 산정 예시이며 Goose 벤치마크가 아니다.** 초기 Pod당 슬롯은 1개다. 더 많은 프로세스를 넣기 전에 격리·메모리·fairness를 재검증한다.

## 10. 성공 조건

역할 추가에 agent Python 코드를 추가하지 않고, 기존 세션의 스킬 버전이 새 배포에 의해 바뀌지 않으며, API/Worker 장애가 다른 사용자의 데이터 유출이나 무조건 재실행으로 이어지지 않아야 한다. 대량 처리 능력은 지정한 환경의 실제 부하 시험으로 보고한다.

첫 개발 지시는 [CODEX_START](../CODEX_START.md), 작업 목록은 [07](07_IMPLEMENTATION_BACKLOG.md), 출시 게이트는 [08](08_TEST_AND_RELEASE_GATES.md)를 따른다.

출처 번호는 [SOURCES.md](SOURCES.md)에서 확인한다. 나머지는 이 프로젝트를 위한 설계 결정이다.
