# 02. 구조와 실행 흐름

## 1. 구성요소의 책임

| 구성요소 | 책임 | 금지할 책임 혼합 |
|---|---|---|
| A2A API | 인증, 역할 선택, Task 접수/조회/구독/취소, Agent Card | Goose 실행을 API 프로세스 메모리에 종속시키지 않음 |
| Goose Worker | 실행권 획득, 환경 준비, ACP 실행, 결과/체크포인트 저장 | 외부 사용자 요청을 직접 받지 않음 |
| PostgreSQL | 배포 메타데이터, Context/Task, 실행권, 이벤트, 중복 방지 | LLM 실행 동안 DB transaction 유지 금지 |
| Object Storage | 해시 고정 스킬 번들, 결과, 체크포인트 | A2A 상태의 별도 경쟁 원장으로 사용하지 않음 |
| Envoy | TLS, 외부 routing, 요청 제한/인증 연계 | business-level Task 권한 검사 대체 금지 |
| MCP | 권한이 제한된 데이터/API 접근 | prompt 지침만으로 read-only 보장하지 않음 |
| LLM Gateway | 모델 연결, 요청/토큰 예산, 관측 | Worker 확장만으로 GPU 용량이 증가한다고 가정하지 않음 |

```text
                     A2A clients
                          |
                    Envoy Gateway
                          |
              +-----------v------------+
              | A2A API x N            |
              | auth / task / stream   |
              +-----------+------------+
                          |
                  PostgreSQL ledger
              +-----------+------------+
              |                        |
         notifications            claim + lease
              |                        |
         API subscribers        Goose Worker x M
                                       |
                                ACP stdio client
                                       |
                                   goose acp
                                 /           \
                         LLM Gateway      MCP services

Object Storage: immutable skills / checkpoints / artifacts
```

ACP stdio는 공식 연결 경로다. Worker가 자식 프로세스의 수명과 통신을 관리하고, 별도 Goose 네트워크 포트를 노출하지 않는 방식으로 시작한다. [SRC-01]

## 2. 논리 객체

- **Role Release:** 역할 설정의 불변 배포본. 역할별 current 포인터는 바뀌어도 release 내용은 바뀌지 않는다.
- **Execution Manifest:** Role/Skill digest, Goose image, 모델/정책 설정 버전 등 실행에 사용한 해석 결과.
- **Context:** 특정 tenant·owner·role에 속한 대화. 고정된 manifest와 마지막 체크포인트를 가진다.
- **Task:** 요청 하나를 추적하는 외부 작업 단위. 실패 후 같은 Task를 외부 완료 상태에서 다시 실행시키지 않는다.
- **Attempt:** Worker가 Task를 실행한 내부 시도. 재시도와 lease 세대는 Task와 별도다.
- **Event:** 진행 또는 상태 변경의 순서 있는 기록. 내부 원문 이벤트와 외부 공개 이벤트를 구분한다.

## 3. 새 요청의 흐름

1. API가 인증 토큰을 검증하고 tenant/principal을 신뢰 가능한 claim과 서비스 설정으로 결정한다.
2. Role 접근권한과 입력 크기·동시 요청·대기열 제한을 확인한다.
3. messageId와 정규화된 입력 digest로 중복 여부를 판정한다. 같은 키의 다른 본문은 충돌로 거부한다.
4. 새 Context라면 current Role release와 Skill digests를 결정해 manifest를 저장한다. 기존 Context라면 저장된 manifest를 사용한다.
5. Task/Message/초기 Event를 한 DB transaction으로 생성한다. 동일 Context의 비종료 Task가 있으면 별도 새 Task를 만들지 않는다.
6. A2A 응답 모드에 따라 즉시 Task를 반환하거나, 스트리밍하거나, 종료/중단 상태까지 기다린다. HTTP 대기와 실행 생명주기는 분리한다.
7. Worker가 tenant fairness와 모델 slot을 고려해 짧은 transaction에서 작업을 claim한다.
8. 사용자별로 분리된 작업 환경에 승인된 스킬만 설치한다. 기존 Context면 체크포인트를 복원한다.
9. Goose를 실행하고 ACP 초기화·capability·도구 연결을 확인한 뒤 prompt를 보낸다.
10. 진행 이벤트를 정제하여 저장한다. API는 DB-backed 이벤트를 구독해 전달한다.
11. 실행 종료 후 결과·체크포인트를 저장하고 lease/세대를 확인해 DB 완료 상태를 확정한다.
12. Goose 자식 프로세스와 MCP 자식이 있다면 종료·reap하고 사용자별 임시 자원을 정리한다.

## 4. 프로세스·디렉터리 경계

초기 상태는 **Pod당 활성 Context 하나, Goose 프로세스 하나**다. 여러 독립 세션을 지원하는 프로토콜 기능과 다중 사용자 보안 격리를 동일시하지 않는다.

실행 디렉터리의 목표 형태:

```text
/work/<opaque-execution-id>/
  home/                  # 해당 실행의 HOME
  xdg-config/            # 검증된 Goose 설정만
  xdg-data/              # 해당 Context의 Goose 세션 DB
  xdg-state/             # 로컬 로그, 비밀/원문 처리 주의
  workspace/
    .agents/skills/      # 허용한 스킬만, 읽기 전용
    .goosehints          # 검증한 필수 역할 지침 전달 경로
    data/                # 승인된 입력/결과 파일
```

HOME/XDG 설정이 선택한 Goose 버전에서 실제 반영되는지 M0에서 확인한다. 모든 저장 위치가 환경변수만으로 이동된다고 가정하지 않는다. workspace 절대 경로를 Goose가 저장한다면 다음 Pod에서도 같은 논리 mount 경로를 재현하거나 검증된 재작성 절차를 사용한다.

Goose 문서에서 권장하는 스킬 경로는 `.agents/skills/`이며 다른 호환 탐색 위치도 존재한다. 허용 경로만 생성하고, 상위 디렉터리와 global config의 뜻하지 않은 스킬·확장 로딩도 검사한다. [SRC-02]

## 5. 외부 의존성과 장애 경계

| 실패 | 처리 |
|---|---|
| API Pod 종료 | Task 실행은 유지, 다른 API에서 조회/재구독 |
| Goose 프로세스 종료 | Worker가 오류를 분류; 마지막 확정 체크포인트는 보존 |
| Worker/Node 종료 | lease 기반으로 감지; 읽기 전용 작업만 제한적 재시도 |
| PostgreSQL 단절 | 신규 접수·claim 중단; Worker는 lease 불확실 시 새 실행/도구 호출 중단 |
| Object Storage 단절 | 성공 확정 보류; 제한적 저장 재시도 후 명시적 오류 |
| LLM 429/포화 | 모델 단위 admission/backoff; 무제한 Worker 증설 금지 |
| MCP timeout | 도구 재시도 가능성과 부작용 여부를 분리하여 판단 |

lease 만료가 기존 프로세스의 사망을 증명하지는 않는다. 상세 fencing/retry 정책은 [05](05_DATA_AND_RECOVERY.md).

## 6. 내부 모듈 초안

```text
src/goose_a2a_runtime/
  api.py                 # app wiring, health
  a2a_service.py         # SDK adapter, public operations
  worker.py              # claim, heartbeat, lifecycle
  goose_acp.py           # 실제 Goose 통신만
  profiles.py            # validation/resolution/materialization
  store.py               # 명시적 SQL, 작은 함수
  checkpoints.py         # snapshot/restore/object store
  security.py            # claims, ownership, policy checks
  events.py              # persistence, public filtering
  settings.py            # env/config validation
```

구체적 module 개수는 구현하면서 조정할 수 있다. 구조를 맞추기 위해 빈 클래스나 generic base를 만들지 않는다. SDK 확장점은 M0에서 정확한 symbol을 확인하고 기록한다.

## 7. 의존성 최소화

초기에는 PostgreSQL의 영속 기록과 알림/짧은 polling으로 시작한다. 알림은 깨울 때만 쓰고 유일한 이벤트 기록으로 쓰지 않는다. Redis·Kafka·별도 Registry·Agent Gateway는 측정된 병목이나 정책 요구가 생길 때 도입한다.

API 전용 TaskStore와 Worker 전용 task DB가 서로 다른 상태를 저장하지 않도록 설계한다. SDK TaskStore를 사용하더라도 **동일한 PostgreSQL 원장에 대한 projection/adapter**여야 한다. SDK의 process-local EventQueue만으로 여러 API replica에 스트리밍을 제공하지 않는다.

참고: [공식 출처](SOURCES.md), [프로토콜 계약](04_A2A_ACP_CONTRACT.md), [데이터·복구](05_DATA_AND_RECOVERY.md).
