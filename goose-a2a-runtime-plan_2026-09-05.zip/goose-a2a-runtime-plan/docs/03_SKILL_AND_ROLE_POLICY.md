# 03. 역할·스킬 주입 정책

## 1. 최종 선택

**배포본은 불변, 바인딩은 세션 시작 시 동적, 본문은 필요 시 로딩한다.**

| 계층 | 변경 시점 | 고정 범위 |
|---|---|---|
| Goose 이미지와 실행 의존성 | 이미지 배포 | 해당 실행 manifest |
| Role current 포인터 | 역할 배포 | 이미 열린 Context에는 미반영 |
| Skill release/digest | 스킬 배포 | 불변 |
| Context의 스킬 집합 | Context 생성 | Context 종료까지 |
| 필수 역할 지침 | Context 시작·복원 | 저장된 digest와 순서 유지 |
| 보조 스킬 본문 | 필요할 때 | 이미 허용한 release의 본문만 |
| 사용자 권한·긴급 차단 | 실행/도구 호출 시 | 최신 정책 적용 |

Goose가 세션 시작 시 스킬 metadata를 발견하고 필요 시 본문을 읽는 기능은 공식 설명에 근거한다. 실행 중 새 파일 설치가 모든 세션에 안전하게 반영된다는 기능은 전제하지 않는다. [SRC-02]

## 2. 필수 지침과 선택 스킬

`required`는 역할의 정체성·업무 범위·근거·결과 형식이다. 초기 instruction에 안정적으로 들어가는 검증된 경로를 사용한다. `.goosehints`는 후보이지만 ACP 흐름에서 실제 읽히는지 S02 검증이 필요하다. [SRC-04]

`available`은 세션에 준비해 두고 필요할 때 읽는 전문 절차다. 기본 loader가 본문을 읽는지 확인하기 위해 관측 가능한 skill-load 이벤트 또는 접근 로그를 남긴다. 모델이 선택 스킬을 매번 사용한다고 보장하지 않는다.

필수 skill을 단순 metadata 목록에만 넣으면 역할이 적용되었다고 판단할 수 없다. 반대로 모든 참고 자료를 무조건 prompt에 붙여 컨텍스트를 낭비하지 않는다.

## 3. 우리 Role Profile 계약

[예제 VOC profile](../examples/roles/voc-analyst.yaml)과 [예제 로그 profile](../examples/roles/log-analyst.yaml)은 [role schema](../examples/schemas/role-profile.schema.json)에 맞는다. **Goose 공식 config가 아니다.**

| 필드 | 의미 |
|---|---|
| `schema_version` | 이 플랫폼의 설정 schema 버전 |
| `id`, `version` | 논리 역할 및 불변 release |
| `runtime.model_profile` | 실제 모델과 인증을 간접 참조 |
| `runtime.worker_pool` | 승인된 실행 풀 |
| `skills.required` | 시작 시 반드시 주입할 스킬 |
| `skills.available` | 필요 시 읽을 수 있는 스킬 |
| `tools.mcp_server_refs` | 관리자가 등록한 서버의 논리 참조 |
| `tools.local_shell` | MVP에서는 false만 허용 |
| `session` | 세션 생성 바인딩, 버전 고정, 한 Task 제한 |
| `execution` | 시간·예산·입출력 제한 |
| `output_schema_ref` | 결과 검증 schema 참조 |
| `a2a.advertised_skills` | 외부에 광고할 능력, 내부 skill과 별개 |

역할 profile에 임의 endpoint, shell command, secret, Python import를 허용하지 않는다. 필요 의존성은 카탈로그와 승인된 이미지에서 해결한다.

## 4. 번들 발행과 해시

발행 과정은 `validate → package → digest → upload → register → activate`다.

빌드 도구는 파일 경로를 정렬하고, POSIX 상대 경로·크기·내용 해시를 담은 canonical manifest의 SHA-256을 계산한다. 정규 JSON 직렬화(키 정렬/고정 separator/UTF-8) 규칙을 코드와 테스트로 고정한다. 압축 파일 자체의 digest는 별도로 보관하여 전송 손상을 확인한다. 타임스탬프·uid·파일 순서로 release 식별자가 흔들리지 않게 한다.

동일한 id/version에 다른 digest를 등록하는 요청은 거부한다. 발행된 release를 수정하지 않고 새 version을 만든다. Role/Skill current 포인터의 활성화는 원자적으로 처리한다.

## 5. 파일·컨텍스트 예산

예제 profile의 제한은 PoC 초기값이며 실제 업무 평가로 조정한다. 바이트 상한과 토큰 상한은 다르다. UTF-8 길이를 토큰 개수로 간주하지 않는다.

압축 해제 전후의 전체 바이트, 파일 수, 개별 파일 크기, 경로 깊이를 제한한다. 절대 경로, `..`, symlink/hardlink, device file, archive bomb를 거부한다. 숨겨진 설정·실행 파일은 명시적 허용 목록으로 다룬다.

필수 스킬의 최대 바이트를 초과하면 일부 내용을 몰래 자르지 말고 역할 배포를 실패시킨다. 참고 자료는 approved reader로 읽게 하며 접근 경로와 반환 크기를 제한한다.

## 6. 스킬 이름과 충돌

MVP는 중첩 dependency 자동 해석을 하지 않는다. Role은 필요한 스킬을 평평한 목록으로 선언한다.

- required/available에 같은 id가 반복되거나 한 id의 여러 버전이 섞이면 거부한다.
- frontmatter의 name과 디렉터리명을 일치시킨다.
- 충돌하는 output schema, 권한 요구, 필수 지침은 발행 검증과 역할 평가에서 처리한다.
- "나중에 읽은 지침이 이긴다"는 암묵적 정책을 만들지 않는다.
- role switch는 기존 Context 수정이 아니라 새 Context 생성이다. 명시적으로 허용된 요약/결과만 넘긴다.

Agent Skills 기본 패키지 형식은 표준을 따른다. MCP binding·권한·배포 version은 별도 플랫폼 설정으로 관리한다. [SRC-05]

## 7. 스킬과 보안 정책의 관계

실제 사용 가능한 도구는 `사용자 권한 ∩ 역할 allowlist ∩ Worker 정책 ∩ 현재 조직 정책`이다. 스킬을 읽었다고 권한이 늘어나지 않는다.

Goose의 Developer extension을 끄면 참고 파일 읽기도 제약될 수 있다. MVP는 **제한된 파일 읽기 ACP callback 또는 read-only MCP resource reader**를 구현·검증한다. 단지 참고 파일을 읽기 위해 shell/임의 파일 접근을 모두 허용하지 않는다.

목록 조회, read-file, terminal, permission callback 등 클라이언트가 제공하는 ACP 기능은 허용한 capability만 advertise한다. 임의 요청을 받으면 명시적으로 거부하고 보안 이벤트를 남긴다.

## 8. 재현성과 변경

Context에 Execution Manifest를 저장한다. Manifest에는 role/skill digest, Goose image digest, 모델의 논리 ID뿐 아니라 모델 설정 release, output schema digest, 초기 policy version을 포함한다. 비밀 토큰은 포함하지 않는다.

고정된 manifest가 동일한 LLM 답변을 보장하지는 않는다. 데이터·모델 weights·sampling·외부 서비스가 달라질 수 있으므로 입력/근거의 버전과 평가 결과도 필요한 범위에서 보관한다.

권한 철회나 취약 skill 긴급 차단은 버전 고정보다 우선한다. 활성 작업 중단·새 작업 차단·사용자 안내 정책은 런북을 따른다.

## 9. 이후 고려할 동적 주입

업무 요구가 확인되면 "한 Context에 새 스킬 추가"를 검토할 수 있다. 이때도 승인된 release만 선택하고 manifest revision, 권한 재검사, 감사, 평가, 세션 컨텍스트 영향 분석이 필요하다. 초기에는 구현하지 않는다.

참고: [예제 카탈로그](../examples/catalogs.example.yaml), [출처](SOURCES.md), [검증 계획](09_COMPATIBILITY_SPIKE.md).
