# 공식 출처와 검증 범위

**열람 기준일: 2026-09-05.** 이 목록은 공개 문서의 내용 확인이며, 실제 Goose/SDK 설치·연동·부하 테스트를 했다는 의미가 아니다. 문서의 `latest`, 저장소 `main`, 기본 branch는 바뀔 수 있으므로 개발 시 tag/commit/package version을 다시 확인하고 고정한다.

본문의 `[SRC-XX]`는 아래 출처를 가리킨다. `S01~S08`은 별도의 선행 검증 작업 ID다. 사례·상태 저장·보안 정책·용량 목표는 이 프로젝트의 설계 결정이며, 출처 프로젝트의 기능 보장으로 읽지 않는다.

## SRC-01 — Goose ACP client 연결

- URL: https://goose-docs.ai/docs/guides/acp-clients/
- 확인: `goose acp`를 자식 프로세스로 실행하는 stdio 연결, ACP client의 생명주기 관리, 세션 저장과 MCP 연계 설명.
- 미확인: 우리 컨테이너·인증·격리·체크포인트 조합의 실행 호환성.

## SRC-02 — Goose Agent Skills

- URL: https://goose-docs.ai/docs/guides/context-engineering/using-skills/
- 확인: 시작 시 metadata 발견, 필요 시 본문 로딩, `.agents/skills/` 및 호환 경로.
- 미확인: 우리 allowlist와 required instruction의 실제 강제 방식, 실행 중 동적 재탐색.

## SRC-03 — Goose 세션·로그 저장

- URL: https://goose-docs.ai/docs/guides/logs/
- 확인: 로컬 SQLite 세션, 대화·도구 관련 저장 및 로컬 로그.
- 미확인: 사용자별 환경 격리·secret 제외·다른 Pod 복원.

## SRC-04 — Goose hints

- URL: https://goose-docs.ai/docs/guides/context-engineering/using-goosehints/
- 확인: `.goosehints`를 통한 지침 제공 경로.
- 미확인: 선택한 ACP/버전/작업 디렉터리에서의 required-role 전달.

## SRC-05 — Agent Skills 규격

- URL: https://agentskills.io/specification
- 확인: `SKILL.md` frontmatter와 본문, 부속 자료 패키지, 단계적 정보 노출.
- 구분: 이 문서의 Role Profile·권한·카탈로그는 자체 제안 규격.

## SRC-06 — 공식 A2A Python SDK

- URL: https://github.com/a2aproject/a2a-python
- 확인: A2A 1.0 지원 설명, 0.3 호환 범위, HTTP/SQL 등 통합 옵션.
- 미확인: 이 프로젝트에 고정할 package 버전과 distributed handler 구현.

## SRC-07 — 공식 ACP Python SDK

- URL: https://github.com/agentclientprotocol/python-sdk
- 확인: `agent-client-protocol` 패키지, async/stdio와 생성된 schema 모델.
- 미확인: 선택한 Goose와의 정확한 SDK 조합.

## SRC-08 — A2A 프로토콜 규격

- URL: https://a2a-protocol.org/latest/specification/
- 확인: 메시지·Task·Artifact·Card 계약, 응답 모드, 구독·취소·권한·직렬화 규칙.
- 미확인: 우리 서비스의 준수 여부. 공식 SDK와 계약 테스트로 확인해야 함.

## SRC-09 — ACP 세션 생성·로드

- URL: https://agentclientprotocol.com/protocol/v1/session-setup
- 확인: 세션 생성과 `loadSession` capability 검사.
- 구분: 프로토콜의 세션 로드와 파일 기반 import/Pod migration은 다름.

## SRC-10 — KEDA PostgreSQL scaler

- URL: https://keda.sh/docs/2.20/scalers/postgresql/
- 확인: PostgreSQL query 기반 scaling 설정.
- 미확인: 실제 설치 버전·HPA metric type·busy Worker 축소 안전성.

## SRC-11 — PostgreSQL SELECT locking

- URL: https://www.postgresql.org/docs/18/sql-select.html
- 확인: row locking과 `SKIP LOCKED` 계약.
- 구분: fairness·quota·lease·fencing은 우리 설계에서 별도로 구현.

## SRC-12 — SQLite backup

- URL: https://sqlite.org/backup.html
- 확인: 일관된 SQLite 백업을 위한 Online Backup API.
- 미확인: 특정 Goose 세션을 복원하는 전체 절차.

## SRC-13 — Kubernetes Pod lifecycle

- URL: https://kubernetes.io/docs/concepts/workloads/pods/pod-lifecycle/
- 확인: 종료 생명주기·유예·정리 절차.
- 구분: 해당 기능이 외부 작업을 자동 checkpoint하는 것은 아님.

## SRC-14 — Kubernetes disruptions

- URL: https://kubernetes.io/docs/concepts/workloads/pods/disruptions/
- 확인: voluntary/involuntary disruption과 PDB 적용 경계.
- 구분: Task durability·busy worker drain은 애플리케이션 책임.

## SRC-15 — MCP 보안 지침

- URL: https://modelcontextprotocol.io/docs/2025-11-25/tutorials/security/security_best_practices
- 확인: token passthrough 등 보안 위험과 대상 검증 필요성.
- 미확인: 사내 issuer·MCP의 실제 위임/교환 지원.

## SRC-16 — Goose CLI 세션 export

- URL: https://goose-docs.ai/docs/guides/goose-cli-commands/
- 확인: `session export`와 JSON/YAML 등의 출력 설명.
- 주의: 대칭인 `session import` 명령을 확인한 것은 아님. checkpoint 복원 spike 필요.

## SRC-17 — ACP prompt turn과 취소

- URL: https://agentclientprotocol.com/protocol/v1/prompt-turn
- 확인: prompt/update, stop reason, `session/cancel`과 취소 결과 확인.
- 구분: 실행 중단은 이미 발생한 외부 부작용의 rollback이 아님.

## SRC-18 — A2A Task 생명주기

- URL: https://a2a-protocol.org/latest/topics/life-of-a-task/
- 확인: Context/Task의 역할, 종료와 후속 대화 관계.
- 구분: 한 Context의 비종료 Task 제한은 우리 서비스 정책.

## 개발 시 기록할 근거

실제 사용한 URL/tag/commit/package version, 테스트 명령, 환경, 정제한 결과를 `docs/evidence/`에 남긴다. 그 디렉터리는 향후 생성할 산출물이다. 문서 열람만으로 실행 상태를 PASS로 바꾸지 않는다.
