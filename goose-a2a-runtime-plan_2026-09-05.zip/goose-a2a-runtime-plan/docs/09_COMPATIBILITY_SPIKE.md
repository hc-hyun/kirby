# 09. 선행 호환성 검증 — M0

## 1. 목적

설계의 가장 큰 위험은 없는 Goose/SDK 기능을 있다고 가정하는 것이다. 아래 항목을 구현 전 또는 작은 spike 코드로 검증하고, [compatibility-matrix.yaml](compatibility-matrix.yaml)과 STATUS에 기록한다.

공식 문서의 지원 설명은 DOCS_ONLY다. 선택한 binary/OS/config/model에서 통과한 결과만 PASS로 적는다. 실패하면 다른 지원 경로를 검토하되 Goose 내부 저장소·설정 함수를 추측해 호출하지 않는다.

## S01 — 실행 버전과 프로토콜

**검증:** Python/OS/architecture, Goose CLI release/image digest, A2A SDK와 ACP SDK exact version, ACP initialize 결과, stdout 순수 protocol/stderr 분리를 확인한다.

**출발점:** `goose --version`, `goose acp`의 CLI 경로가 공식 문서에 있다. 이 명령은 설치를 수행하지 않으며 실제 JSON-RPC client가 통신을 해야 의미 있는 검증이 된다. [SRC-01]

**산출물:** 정제한 initialize 응답, 지원 capability 목록, import symbol 목록, lockfile, 재현 절차.

**실패 시:** binary 설치/호환성 문제를 기록하고 fake peer로 계약 테스트만 진행한다. `latest` 태그로 얼버무리지 않는다.

## S02 — 역할·스킬과 필수 지침

**검증:** 분리 HOME와 `.agents/skills` 두 환경에 서로 다른 skill을 놓고 new session을 생성한다. discovery 목록, required instruction 적용, optional skill 본문 접근, global/상위 경로 오염을 확인한다. `.goosehints`가 실제 ACP 경로에서 적용되는지 확인한다. [SRC-02][SRC-04]

**산출물:** VOC/로그 역할의 입력·출력·skill-load 근거와 검증한 설정 변환 함수.

**실패 시:** 지원된 instruction 설정이나 recipe 경로를 비교한다. 임의 flags를 만들지 않는다. prompt 문자열만 바꾼 것을 native skill 로딩 검증이라고 하지 않는다.

## S03 — 도구·파일·사용자 경계

**검증:** MCP 조회 하나만 허용한 상태에서 terminal, 파일 쓰기, 다른 HOME, 임의 endpoint, default extension, permission auto-approve를 시도한다. ACP callbacks와 Goose built-ins 모두 검사한다.

**산출물:** 실제 노출 tool 목록, allow/deny 결과, read-only reference reader 방법.

**실패 시:** 최소 권한 pool을 보완하거나 합성 데이터 전용 pilot으로 제한한다. prompt 기반 제한만으로 통과하지 않는다.

## S04 — streaming/cancel/lifecycle

**검증:** 텍스트 chunk와 tool 업데이트를 받고 중간에 취소한다. 원래 prompt의 stop reason, 취소 직후 지연 이벤트, terminal/file/permission callbacks 정리, 자식 process tree를 확인한다. [SRC-17]

**산출물:** 정상/취소/강제종료 이벤트 fixture와 integration test.

**실패 시:** 취소를 지원한다고 advertise하지 않는다. 제한 실행 시간과 강제 종료가 가능한지 별도로 평가한다.

## S05 — native 체크포인트 복원

**검증 시나리오:**

1. Context A에서 대화와 read-only tool 호출을 한 뒤 턴을 종료한다.
2. 공식 export 또는 일관된 SQLite backup을 생성한다.
3. Goose 프로세스를 완전히 종료한다.
4. 비어 있는 별도 HOME/임시 root에 복원한다. 이전 root에 접근할 수 없게 한다.
5. initialize/loadSession capability와 검증된 import/restore 경로로 이어서 질문한다.
6. tool 결과 문맥, working directory, skill 버전, 결과 schema, 사용자 credential 재바인딩을 확인한다.
7. 같은 절차를 다른 Pod에서도 수행한다. image/format mismatch는 명시적으로 거부한다.

**주의:** Goose CLI 문서에는 JSON/YAML session export가 있으나, 이 패키지는 대칭인 `session import` 명령의 존재를 확인하지 않았다. 그런 명령을 발명하지 않는다. [SRC-16] ACP `session/load`는 보유 세션을 로딩하는 계약이지 외부 object 파일을 자동 import하는 API가 아니다. [SRC-09]

**산출물:** restore 절차와 exact version, snapshot 내용 분류, secret 검사, 경로·ID 변경 규칙.

**실패 시:** frozen/pinned pilot을 선택하고 M2/M3 이동 복구는 BLOCKED로 둔다. raw 메시지만 새 prompt에 붙여 원래 세션 복원이라고 표시하지 않는다.

## S06 — LLM Gateway·MCP 연결

**검증:** 사용 가능한 provider 설정으로 사내 또는 전용 테스트 endpoint에 연결한다. 모델 ID, OpenAI-compatible API의 실제 지원 범위, tool calling, streaming, timeout, authentication, 사내 CA를 확인한다. read-only MCP의 인증과 사용자 범위도 확인한다.

**산출물:** 비밀 없는 config recipe, logical profile→실제 config mapping, 최소 smoke test.

**실패 시:** 명시적인 test-only model/MCP fixture를 사용한다. 임의 공개 모델로 실제 내부 데이터를 보내지 않는다.

## S07 — A2A SDK 확장점

**검증:** 선택한 SDK로 Agent Card/Send/Get/Stream/Cancel을 직렬화하고 공식 client가 읽게 한다. 기본 blocking semantics, version negotiation, TaskStore/RequestHandler/Executor의 확장점을 검사한다. 분리 Worker와 DB event tail을 연결할 위치를 기록한다. [SRC-06][SRC-08]

**산출물:** `docs/evidence/sdk-api-map.md`에 실제 클래스/함수/인자/import 경로와 package version을 기록한다. 해당 경로는 앞으로 만들 산출물이며 현재 포함돼 있지 않다.

**실패 시:** SDK의 다른 공식 통합 경로를 검토한다. process-local executor queue를 분산 서빙으로 포장하지 않는다.

## S08 — budget 강제와 비밀 보관

**검증:** wall-clock, model request count, output/input size 제한이 실제 집행되는지 확인한다. 제한을 넘기려는 prompt와 fake long-running request로 시험한다. 가짜 canary credential을 config/MCP에 넣고 session DB, checkpoint, logs, traces, A2A 결과를 검사한다.

**산출물:** 각 설정의 enforcement 위치와 PASS/FAIL, credential 수명·재바인딩 계획.

**실패 시:** 집행되지 않는 설정을 hard limit으로 광고하지 않는다. 지원 hook/gateway 제한을 추가하거나 해당 pool 출시를 차단한다. 비밀이 포함된 snapshot을 단순 암호화해서 일반 사용자에게 제공하지 않는다.

## 2. 버전 고정 정책

Goose binary/image digest, Python dependency lock, protocol target, model configuration release, skill/schema digest를 함께 기록한다. schema와 protocol family 이름이 같아도 SDK release/API가 같다는 뜻은 아니다.

업그레이드는 기존 체크포인트 복원, required skills, tool restrictions, serializer, cancel, secret 검사 회귀를 통과해야 한다. 진행 중 Context가 사용하는 이미지를 무조건 최신으로 대체하지 않는다.

## 3. 검증 코드의 관리

짧은 실험 코드는 `tests/spikes/` 또는 `scripts/spikes/`에 만들고, 유효한 부분만 production module로 이동한다. 재현 명령과 입력 fixture를 남긴다. 실제 고객 데이터·토큰·사내 endpoint 상세는 공개 fixture에 넣지 않는다.

`NOT_RUN`은 실패가 아니라 미검증 상태다. 다만 필수 출시 게이트에서는 통과로 취급하지 않는다.

참고: [출처](SOURCES.md), [상태](../STATUS.md), [백로그](07_IMPLEMENTATION_BACKLOG.md).
