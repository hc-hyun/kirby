# 10. 운영·장애 대응 런북 초안

이 문서는 구현할 관측·관리 기능을 전제로 한 운영 절차 초안이다. 현재 실행 가능한 관리 CLI나 dashboard가 이미 존재하는 것은 아니다. 실제 배포 후 B15에서 정확한 명령을 채운다.

## 1. 기본 진단 순서

`외부 API/인증 → admission/quota → DB queue/lease → Worker spawn/restore → LLM/MCP → result/checkpoint commit` 순으로 지연을 나눈다. task_id 하나를 따라가되 일반 로그에서 원문 내용은 열지 않는다.

## 2. 장애별 대응

| 증상 | 우선 확인 | 안전한 대응 |
|---|---|---|
| 접수 401/403 | issuer/audience/claim mapping/권한 만료 | 정책 검증; 우회 인증 금지 |
| queue만 증가 | 모델 slot/429, Worker claim, tenant quota | 원인에 따라 admission 축소 또는 검증된 pool 증설 |
| CPU 낮지만 느림 | LLM queue, MCP latency, DB pool | Worker 추가 전에 외부 병목 확인 |
| Task가 working에 고정 | heartbeat, lease, attempt, Goose process | read-only 여부 확인 후 fencing/recovery |
| 취소 후 계속 호출 | pending ACP callback, subprocess, remote request | 프로세스 정리·도구 credential 차단; 상태 정정 |
| checkpoint 오류 | object 접근, size/digest, Goose format | 이전 확정 checkpoint 유지, 새 빈 세션 복원 금지 |
| 특정 역할만 실패 | role/skill/model/schema release | 새 Context 배포 rollback, 기존 Context 정책 확인 |
| DB 연결 소진 | SSE당 연결, Worker pool, migration | bounded pool/reader 조정; DB 증설만으로 덮지 않음 |
| cross-user 유출 의심 | trace·role·owner mapping·workspace | 해당 pool 접수 중단·격리·감사, 로그 보존 |

## 3. 스킬 배포와 rollback

1. 새 release를 검증·평가하고 digest와 schema를 확정한다.
2. 허용된 test tenant 또는 canary 역할에서 시험한다.
3. current 포인터를 원자적으로 변경한다.
4. 새 Context의 실패율·invalid-output·token·latency를 비교한다.
5. 문제 시 current만 이전 release로 돌린다. 기존 Context의 manifest를 몰래 수정하지 않는다.

보안 취약 release라면 일반 rollback과 다르게 해당 digest를 blocklist에 넣고 기존 세션의 추가 실행도 막는다. 필요 시 Task 취소/credential 회수와 사용자 재시작 안내를 진행한다.

## 4. Goose·SDK 이미지 업데이트

새 이미지에서 기존 체크포인트 복원·프로토콜·도구 제한을 회귀 테스트한다. 기존 세션이 참조하는 이미지의 실행 풀을 유지하거나 명시적으로 검증된 migration을 제공한다. 단순 deployment image 변경만으로 모든 세션이 호환된다고 가정하지 않는다.

drain 동안 신규 claim은 중단하되 현재 lease heartbeat와 결과 정리는 유지한다. 종료 유예를 넘긴 작업은 명시적 recovery 경로로 보낸다.

## 5. 권한·비밀 회수

권한 철회 후 신규 작업만 막고 기존 Context는 허용하는 상태를 피한다. 실행 시작과 도구 호출 정책에서 최신 권한을 확인한다. 이미 장기 원격 요청이 실행 중이라면 해당 서비스의 취소/credential 폐기 경로를 함께 사용한다.

key rotation 시 Role/Skill digest를 수정할 필요가 없게 secret reference를 사용한다. token이 snapshot에 포함됐는지 검사한 결과를 유지한다.

## 6. 저장소 정리

Task 결과·checkpoint가 참조하는 skill/image/schema를 먼저 확인한다. orphan 객체는 충분한 유예기간 후 삭제한다. snapshot 작성 중인 객체나 rollback에 필요한 객체를 지우지 않는다.

사용자 데이터 삭제는 본문·artifact·checkpoint·logs·DB backup 보존 경계까지 포함해 관리한다. dedup tombstone에는 최소한의 식별·digest만 남기며 정책에 맞게 만료한다.

## 7. 백업 복원 연습

PostgreSQL 백업 시점과 Object Storage의 불변 객체가 함께 유효한지 검사한다. DB에 참조된 객체가 누락되면 해당 Context를 손상 상태로 표시하고 자동 실행하지 않는다. isolated namespace에서 복원하며 원래 운영 Worker와 동시에 실행권을 갖지 않게 한다.

## 8. 출시 보고서에 채울 값

실제 image/sdk versions, cluster/DB/storage versions, 승인된 SLO와 limit, 최대 검증 slot, 부하 입력과 결과, retention, access model, 알려진 제약, rollback 방법, 장애 대응 책임자를 기록한다.

"등록 사용자 1만 명 대응"처럼 사용 패턴 없는 수치를 쓰지 않는다. 활성 사용자, 요청률, 작업 시간 분포, 모델/도구 구성을 함께 기재한다.
