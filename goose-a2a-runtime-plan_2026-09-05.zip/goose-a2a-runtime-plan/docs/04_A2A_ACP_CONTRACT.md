# 04. A2A · ACP 서비스 계약

## 1. 버전과 SDK 사용

초기 외부 프로토콜은 **A2A 1.0 계열 JSON-RPC**, 내부는 **Goose의 ACP stdio**다. 정확한 SDK release와 프로토콜 협상 결과는 M0에서 고정한다. 공식 Python SDK는 A2A 1.0 및 0.3 호환 범위를 설명하지만, 본 서비스가 두 버전을 모두 지원해야 하는 것은 아니다. [SRC-06]

A2A의 ProtoJSON field/enum, method 이름, message part 구조는 SDK 직렬화를 그대로 사용한다. `message/send` 등 과거 예제를 확인 없이 복사하지 않는다. 본 문서의 내부 상태·DTO 이름은 wire schema가 아니다.

## 2. 공개 범위

| 기능 | 초기 목표 |
|---|---|
| Agent Card | 역할별 생성, 실제 지원 기능만 광고 |
| Send Message | blocking과 명시적 non-blocking 의미 준수 |
| Send Streaming Message | 초기 Task와 진행/결과 이벤트 |
| Get Task / List Tasks | owner/role/tenant 범위, pagination |
| Subscribe to Task | 비종료 Task의 현재 snapshot과 이후 업데이트 |
| Cancel Task | 취소 요청 저장 후 실제 실행 중단 확인 |
| Artifact | 텍스트/JSON, 이후 승인된 파일 다운로드 |
| Push notifications | 제외, 지원하지 않는 capability로 표시 |
| gRPC / REST binding | 제외 |
| 장시간 사용자 승인/인증 대기 | 후속 범위 |

A2A 1.0의 blocking 기본값을 무시하고 모든 요청에 접수된 Task만 반환하지 않는다. 명시적 즉시 반환 설정은 SDK의 해당 필드를 사용한다. Subscribe는 완료 Task의 과거 로그 다운로드 API가 아니다. [SRC-08]

## 3. 주소와 Agent Card

배포상의 예시 mount prefix는 `/agents/voc`와 `/agents/log`다. 실제 JSON-RPC endpoint와 card URL은 SDK 구성으로 확정한다. prefix별 `/.well-known/agent-card.json` 경로를 제공한다면 registry에 정확한 card URL을 저장하고 client가 이를 사용하게 한다.

한 host 루트의 well-known card가 자동으로 여러 역할을 나열한다고 가정하지 않는다. 역할 목록이 필요하면 별도 내부 catalog API로 제공하며 그것을 A2A 표준 기능이라고 부르지 않는다. reverse proxy의 scheme/host/path와 card의 외부 URL을 테스트한다.

외부 advertised skill은 "VOC 분석", "로그 분류"처럼 업무 능력이다. 내부 `SKILL.md` 경로, DB 주소, 토큰, 개인별 접근 가능한 데이터 범위를 card에 노출하지 않는다.

## 4. 요청 정규화 — 내부 DTO 초안

```text
Principal:
  tenant_id, subject_id, client_id, effective_roles

TaskInput:
  role_id, context_id?, task_id?, message_id
  accepted_parts, request_digest, requested_response_mode

ResolvedExecution:
  context_id, task_id, attempt_id, lease_generation
  execution_manifest_id, deadline_at, credential_reference

PublicEvent:
  task_id, seq, event_type, safe_payload, created_at
```

이는 우리 코드의 계약 초안이다. 생성형 SDK 클래스로 오해하지 않는다. 사용자 본문에서 전달받은 tenant/client/secret을 그대로 채우지 않는다.

## 5. A2A와 Goose의 식별자

- A2A contextId, Task ID, messageId는 서로 다른 목적의 값이다.
- Goose session ID는 내부 복원 참조이며 A2A contextId로 바로 사용하지 않는다.
- Task와 Goose prompt 실행은 보통 1회 대응하지만 재시도 attempt와 추가 입력 때문에 항상 1:1이라고 가정하지 않는다.
- 완료/실패/취소/거부된 Task는 다시 실행 상태로 되돌리지 않는다. 후속 질문은 같은 Context에서 새 Task를 만든다. [SRC-18]

A2A `tenant` routing 값이 있더라도 인증된 tenant를 대체하지 않는다. 둘이 충돌하면 거부한다.

## 6. 내부 상태의 외부 projection

다음 외부 명칭은 설명용 의미다. wire enum 값은 SDK를 사용한다.

| 내부 상태 | A2A 의미 | 비고 |
|---|---|---|
| QUEUED | submitted | DB에 접수됨 |
| CLAIMED / STARTING / RUNNING | working | 실제 Worker 실행 시작 및 진행 |
| RETRY_WAIT | working | Task는 종료되지 않음, 시도만 변경 |
| COMMITTING | working | 결과·체크포인트 확정 전 |
| CANCEL_REQUESTED | 이전 비종료 상태 유지 | 취소 요청 사실을 별도 진행 정보로 표시 |
| SUCCEEDED | completed | 저장 후 확정 |
| FAILED / TIMED_OUT | failed | 원인 코드는 metadata/error에 구분 |
| CANCELED | canceled | 실제 중단 또는 미실행 확인 |
| REJECTED | rejected | 안전/업무 정책상의 거부 |
| WAITING_INPUT | input-required | 안전한 중단·재개를 구현한 경우만 사용 |

인증/권한/잘못된 요청 오류는 무조건 Task를 만들어 실패 상태로 저장하는 대신 SDK의 적절한 요청 오류를 사용한다. 자원 존재 여부가 새지 않도록 일관된 오류 계약을 둔다.

## 7. ACP 실행 계약

`spawn → initialize → capability 확인 → session/new 또는 session/load → session/prompt → session/update 수집 → stop reason 확인` 순으로 실행한다. `loadSession` 지원 여부를 초기화 응답에서 확인한다. [SRC-09]

| ACP 입력/결과 | 플랫폼 처리 |
|---|---|
| 새로운 prompt | 인증된 입력만 Goose에 전달 |
| assistant text chunk | 크기 제한·정제 후 공개 이벤트 후보 |
| tool call/update | raw arguments/result는 기본 비공개, 상태만 정제 |
| reasoning/thought/internal metadata | 외부 A2A artifact나 일반 로그로 공개하지 않음 |
| file/terminal callback | 허용 capability와 경로 범위 검증; 기본 쓰기/terminal 거부 |
| permission request | 임의 자동 승인 금지; MVP 정책에 따라 거부 |
| prompt stop reason | 성공/취소/제한/거부를 구분하여 projection |

`end_turn`은 우리 결과 schema의 유효성과 별도다. JSON 파싱/schema 검증을 통과해야 성공 처리한다. 최초 출력이 잘못되면 선택적으로 제한된 교정 요청 1회까지 허용하되 같은 예산·감사 범위에 포함하고 결과를 기록한다. Python 실행 등으로 검증을 우회하지 않는다.

## 8. 취소와 경합

취소 요청은 DB에 영속화한다. QUEUED이면 claim과 동일한 원자적 경계에서 CANCELED로 전환할 수 있다. 실행 중이면 Worker가 ACP 취소 notification을 전송한다.

ACP에서는 취소 후 원래 prompt 응답의 `cancelled` stop reason으로 중단을 확인한다. 취소를 요청한 뒤 도착한 정리용 이벤트도 처리해야 한다. [SRC-17]

프로젝트 정책:

- success commit과 cancel request는 Task row를 대상으로 순서를 직렬화한다.
- 성공이 먼저 확정되면 그 결과를 유지하고, 취소가 과거 성공을 바꾸지 않는다.
- 취소 요청이 먼저 확정되면 일반 성공 commit을 거부하고 중단/정리 경로로 간다.
- grace period 후에도 응답이 없으면 자식 프로세스 그룹을 종료하고 reap한다. 종료 확인도 못한 상태를 성공적인 취소로 표시하지 않는다.
- LLM·MCP 원격 요청의 실제 중단 여부와 이미 완료된 부작용은 별도다. 취소가 rollback을 뜻하지 않는다.

## 9. 스트리밍과 재연결

DB의 Task snapshot과 이벤트 순서 번호를 원장으로 삼는다. API 인스턴스 메모리는 전송 버퍼일 뿐이다.

구독을 시작할 때 일관된 snapshot과 high-watermark `seq=N`을 읽고, 이후 `seq>N`을 전달한다. 알림 유실·중복을 허용하되 DB에서 빈 구간을 다시 읽는다. 느린 client는 bounded buffer/connection timeout으로 분리하며 Worker를 멈추지 않는다.

외부에는 생성 순서를 지키고 한 스트림의 종료가 Task나 다른 구독을 취소하지 않게 한다. [SRC-08]

MVP는 **Task 현재 상태와 최종 Artifact 복구**를 보장한다. 모든 토큰을 처음부터 동일하게 재생하는 기능이나 arbitrary Last-Event-ID resume를 A2A 표준으로 광고하지 않는다. 상세 로그 재생이 필요하면 인증된 별도 endpoint 또는 명시적 확장을 후속 설계한다.

재시도 attempt에서 만들어진 미완료 텍스트는 provisional이다. attempt ID와 artifact ID를 분리하고 새 attempt가 시작됐음을 알려 중복 결과가 하나의 확정 답변처럼 합쳐지지 않게 한다.

## 10. 사용자 추가 입력과 승인

MVP의 일반 후속 질문은 완료된 Task 이후 같은 Context의 새 Task다. 모델이 물음표를 썼다는 이유만으로 input-required 상태를 추론하지 않는다.

WAITING_INPUT을 구현할 때는 명시적 입력 요청, 안전한 턴 종료, 체크포인트, 입력 기한, 동일 Task에 대한 새 messageId의 수용 경로가 필요하다. 프로세스 안의 pending permission future를 DB의 input-required로 바꿨다고 재시작 가능해지지 않는다. 장기 쓰기 승인은 M4로 분리한다.

## 11. SDK 통합의 주의점

DefaultRequestHandler/Executor 예제를 그대로 써도 분산 큐·브로드캐스트가 생기는 것은 아니다. M0의 S07에서 실제 SDK의 service/request-handler/task-store 확장점을 확인하고, admission과 DB-backed 조회/이벤트의 소유권을 한 곳에 둔다.

M1의 in-memory 테스트 구현은 명시적인 개발 전용 경로로 격리하고 M2에서 default로 남기지 않는다. unsupported feature를 조용히 성공으로 처리하지 않는다.

참고: [SOURCES.md](SOURCES.md), [데이터 모델](05_DATA_AND_RECOVERY.md).
