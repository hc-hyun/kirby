# 08. 테스트와 출시 게이트

## 1. 검증 원칙

문서·코드 존재, fake 테스트 성공, 실제 Goose 테스트 성공, Kubernetes 부하 성공은 다른 증거다. 각각 따로 기록한다. 현재 패키지는 실제 서비스 테스트를 실행하지 않았다.

테스트 marker 제안: `unit`, `contract`, `postgres`, `goose`, `k8s`, `load`, `security`. 자격증명이 필요한 테스트는 명시적으로 opt-in하며, skip 이유와 환경 상태를 출력한다. CI 기본 job은 비용 없는 unit/contract 중심이다.

## 2. 기능과 계약

| ID | 시험 | 통과 조건 | 단계 |
|---|---|---|---|
| T01 | 공식 A2A SDK wire round-trip | target version의 직렬화·오류·Card를 공식 client가 해석 | M0/M1 |
| T02 | blocking/non-blocking | 기본 wait와 명시적 즉시 반환 의미를 준수 | M1 |
| T03 | 동일 이미지의 두 역할 | VOC·로그 역할이 각각 허용된 스킬과 출력 schema 사용 | M1 |
| T04 | required skill 적용 | metadata 목록만이 아니라 필수 지침 적용 근거 | M0/M1 |
| T05 | available skill 지연 로딩 | 필요 시 본문만 읽고 다른 역할 스킬은 미노출 | M1 |
| T06 | 결과 schema | invalid JSON/schema에 성공 표시하지 않음 | M1 |
| T07 | follow-up | 완료 Task는 불변, 같은 Context의 새 Task가 대화 문맥 활용 | M1/M2 |
| T08 | unknown capabilities | 미지원 method/part/permission을 조용히 성공 처리하지 않음 | M1 |

역할 품질 평가에는 가상 샘플만 사용하고, 실제 현업 taxonomy나 정상동작 기준으로 오인하지 않는다. 자동 schema test와 도메인 정확도 평가는 별도다.

## 3. 분산 상태·복구

| ID | 시험 | 통과 조건 | 단계 |
|---|---|---|---|
| T09 | 같은 message 동시 재전송 | 동일 Task/Context 반환, Goose 실행 중복 없음 | M2 |
| T10 | messageId 동일·본문 다름 | 충돌로 거부 | M2 |
| T11 | 동일 Context 동시 요청 | 비종료 Task 하나; 나머지는 일관된 busy 응답 | M2 |
| T12 | API 종료 | Task 지속; 다른 API에서 Get/구독 가능 | M2 |
| T13 | Worker 강제 종료 | 최종 checkpoint 보존, 허용된 read-only retry만 수행 | M2 |
| T14 | stale lease 결과 | 이전 generation의 결과·checkpoint commit 거부 | M2 |
| T15 | 다른 HOME/Pod 복원 | tool 문맥·skill digest·경로·권한 유지 | M0/M2 |
| T16 | checkpoint 손상·버전 불일치 | 명시적 오류/격리; 새 빈 세션으로 위장 복원하지 않음 | M2 |
| T17 | Object upload 후 DB 실패 | 참조 없는 객체 정리, Task 허위 성공 없음 | M2 |
| T18 | DB commit 후 응답 단절 | 같은 결과 조회, 재실행하지 않음 | M2 |
| T19 | cancel/success 동시 도착 | 상태가 한 번만 terminal로 확정 | M2 |
| T20 | cancel 후 자식 프로세스 | Goose/MCP 자식 정리, 실제 취소 결과 확인 | M1/M2 |
| T21 | 느린 스트림·재접속 | bounded memory, 이벤트 순서 유지, 다른 구독 영향 없음 | M2 |
| T22 | DB 단절·lease 불확실 | 신규 실행/결과 확정 중단; 복구 후 재검증 | M2 |

추가 crash point는 `claim 직후`, `LLM 요청 전송 직후`, `결과 파일 업로드 직후`, `checkpoint 업로드 직후`, `성공 commit 직전/직후`로 나눠 주입한다. 재시도 시 이전 입력이 두 번 포함되지 않는지도 검사한다.

## 4. 보안·권한

| ID | 시험 | 통과 조건 | 단계 |
|---|---|---|---|
| T23 | tenant/owner/role ID 변조 | 조회·list·cancel·subscribe·download 모두 차단 | M2 |
| T24 | HOME/config/workspace 침범 | 타 실행 데이터 접근 불가 | M0/M2 |
| T25 | prompt injection 통한 Shell/DB write | 실제 도구 경계에서 차단 | M0/M3 |
| T26 | archive traversal/bomb/symlink | materialize 전 거부 | M1 |
| T27 | secret canary | prompt/log/trace/checkpoint/card/artifact에 유출 없음 | M0/M3 |
| T28 | 권한/skill 긴급 회수 | 기존 세션의 이후 접근도 차단; 실행 중단 정책 작동 | M3 |
| T29 | token audience/issuer/expiry | 위조·다른 서비스용 토큰 거부 | M3 |
| T30 | 임의 URL·metadata IP | SSRF/내부 관리망 접근 차단 | M3 |

T27은 실제 비밀 대신 가짜 canary 값을 사용한다. Goose 네이티브 DB·로그까지 검사한다. service credential이 DB row 권한을 우회하는 경로도 반드시 포함한다.

## 5. 배포·부하

| ID | 시험 | 통과 조건 | 단계 |
|---|---|---|---|
| T31 | Role v2 배포·rollback | 기존 Context는 v1 digest 유지, 새 Context만 전환 | M2/M3 |
| T32 | 자동 확장·축소 | 적격 queue 처리, 실행 중 작업의 drain/recovery 검증 | M3 |
| T33 | model saturation | slot/queue 상한 준수, pod 무한 증설 없음 | M3 |
| T34 | tenant fairness | 한 tenant가 다른 tenant를 기아 상태로 만들지 않음 | M3 |
| T35 | queue hard limit | 허용 범위 이상은 명시적 거절, DB 무한 성장 없음 | M3 |
| T36 | rolling update/node loss | 재현 가능한 복원 또는 명시적 실패, 유출 없음 | M3 |
| T37 | 장기 반복 실행 | process/FD/connection/memory/tempfile 누적 누수 없음 | M3 |
| T38 | backup/restore·retention | DB/Object 연결 복원, 삭제·dedup 정책 일관 | M3 |

## 6. 부하 프로파일 제안

아래는 **실측 결과가 아닌 시험 입력안**이다. 환경이 준비되면 한계를 측정하고 승인된 목표로 수정한다.

### A. 인프라 계약 시험 — fake backend

100개 synthetic user, 초당 20개의 고유 요청, fake 작업 1초, 목표 32개 실행 slot, 5분 지속을 초기 입력으로 사용한다. 중복 요청·취소·stream reconnect를 일부 섞는다. 이 시험은 Goose/LLM 성능을 측정하지 않는다.

초기 목표안: 정상 admission p95 500ms 이하, 중복 Task 실행 0, cross-tenant 유출 0, 데이터 commit 후 결과 유실 0. 시험 자원·DB latency가 달라지면 근거와 함께 조정한다. 모델 응답 속도를 이 지표에 섞지 않는다.

### B. 실제 Goose/LLM 시험

동시 slot 1→4→8→16 순으로 단계적으로 평가하되 실제 모델 예산을 넘지 않는다. 동일한 가상 VOC/로그 workload로 queue time, model time, 도구 time, RSS, token 사용, 유효 결과율을 기록한다. 최대 동시 사용자 수는 이 결과에서 도출한다.

### C. 안정성 시험

선정한 안전 용량에서 60분 반복 입력을 주는 프로파일을 제안한다. checkpoint/GC/로그 회전·credential 만료·MCP 재연결·scale-down 이벤트를 포함한다. 운영 서비스의 장기 신뢰성 보장과 동일시하지 않는다.

## 7. 마일스톤 게이트

| 게이트 | 반드시 확보할 근거 | 차단 조건 |
|---|---|---|
| M0 | S01~S08 결과와 version matrix | 핵심 ACP/권한 경계 미확인 |
| M1 | T01~T08, T20; 실제 Goose 경로 | fake만 실행하고 실제 지원이라고 주장 |
| M2 | T09~T24, T26, T31; 분리 프로세스 | memory-only TaskStore, 복원 미검증, user 격리 실패 |
| M3 | 모든 적용 가능한 T ID + 운영 runbook | 고위험 보안 실패, 무한 queue, rollback/restore 부재 |

WAITING_INPUT·push notifications·outbound A2A·쓰기 등 후속 기능 테스트는 미지원 기능을 disabled로 유지하는 테스트로 대체한다. 기능을 advertise하면 해당 end-to-end 검증이 새로운 필수 게이트가 된다.

## 8. 증거 보고서 형식

```text
test_id, timestamp, git_commit, image_digest,
goose_version, a2a_sdk_version, acp_sdk_version,
profile_digest, model_profile_release, environment,
command, expected, observed, PASS|FAIL|NOT_RUN,
redacted_log_or_report_path
```

증거 없이 PASS를 채우지 않는다. 코드 coverage 비율만으로 lease·취소·유출 경계의 안전성을 평가하지 않는다.
