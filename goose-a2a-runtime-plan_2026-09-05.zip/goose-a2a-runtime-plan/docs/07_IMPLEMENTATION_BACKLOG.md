# 07. 구현 백로그

이 문서의 작업은 모두 **계획 상태**다. 실행 상태는 [STATUS.md](../STATUS.md)에 기록한다. 한 작업은 작은 변경 묶음으로 끝내고, 선행 조건과 테스트 근거 없이 다음 단계의 기능을 완료로 표시하지 않는다.

## 1. 진행 순서

```text
B00 → S01~S08
      ├─ 검증 가능 → B01 → B02/B03 → B04 (M1)
      └─ 환경 부재 → fake 계약 테스트 + BLOCKED 기록

B05 → B06 → B07/B08 → B09/B10/B11 (M2)
     → B12 → B13 → B14 → B15 (M3)

F01~F04는 후속 범위
```

S05의 이동 복원이 막혔을 때 로컬/pinned pilot은 가능하지만 M2/M3의 전체 게이트는 통과할 수 없다. S03/S08의 권한·secret 경계가 막히면 실제 고객 데이터는 사용하지 않는다.

## 2. 기반과 호환성 — M0

| ID | 작업 | 선행 | 산출물 | 완료 조건 |
|---|---|---|---|---|
| B00 | 저장소·개발 환경 조사와 uv 초기화 | 없음 | pyproject, src/tests skeleton, 기존 코드 조사 기록 | 사용자 변경 보존, unit test와 Ruff 실행 가능 |
| S01 | Goose/SDK 버전·handshake 검증 | B00 | 버전 lock, 초기화 응답 정제 fixture | 실제 binary/protocol/capability 근거 |
| S02 | 역할·스킬 로딩 경로 검증 | S01 | 두 역할 smoke test, 경로 목록 | 필수 지침 적용, 타 역할 스킬 미노출 |
| S03 | 도구·파일·사용자 격리 검증 | S01,S02 | deny/allow 공격 테스트 | shell/타 사용자 파일/임의 MCP 차단 |
| S04 | ACP 스트림·취소·자식 정리 | S01 | cancel fixture, process lifecycle test | 실제 취소 확인과 orphan process 없음 |
| S05 | checkpoint→새 프로세스 복원 | S01,S02 | 복원 도구 spike, 비교 결과 | 분리 HOME/경로에서도 문맥·버전·권한 유지 |
| S06 | 사내/테스트 LLM·MCP 연결 | S01 | provider 설정 recipe와 read-only 호출 근거 | 실제 model ID와 endpoint 방식 검증 |
| S07 | A2A SDK의 분산 서빙 확장점 | B00 | API symbol/serializer 검증, sample contract test | queue 분리·DB projection 구현 위치 명확 |
| S08 | 예산·secret·로그 강제 경계 | S03,S06 | enforcement matrix, secret canary 검사 | advertised hard limit 집행, 비밀 유출 차단 |

상세 절차와 실패 시 처리는 [09](09_COMPATIBILITY_SPIKE.md)에 있다. 정보 확인만 한 항목은 DOCS_ONLY이며 실행 PASS가 아니다.

## 3. 단일 사용자 수직 기능 — M1

### B01. 테스트 가능한 실행 경계

선행: B00, S07의 최소 wire 검증.

`goose_acp.py`의 작은 실행 경계와 fake ACP peer를 만든다. 별도 범용 runtime framework는 만들지 않는다. fake는 chunk, tool error, delay, cancel, nonzero exit를 생성할 수 있어야 한다. 외부 LLM 없이 테스트한다.

완료: fake message→Task result, timeout, cancel, stdout protocol/stderr log 분리 테스트가 실행된다. fixture를 실제 Goose 결과로 오인하지 않게 이름에 fake를 표시한다.

### B02. Role/Skill validation과 resolver

선행: B01, S02.

예제 Role Schema를 코드 모델과 맞추고, required/available 중복·버전·참조·크기·경로를 검증한다. release digest와 Execution Manifest를 만든다. immutable local bundle storage로 시작하되 registry 인터페이스를 과도하게 추상화하지 않는다.

완료: 새 Role 배포가 기존 manifest를 바꾸지 않고, 공격 archive와 임의 tool URL이 거부된다. 예제 두 역할이 같은 이미지 설정을 참조한다.

### B03. 실제 Goose ACP adapter

선행: B01, S01~S04, S06; S08의 최소 보안 결과.

spawn, isolated environment, capability 확인, session/new, prompt/update, safe tool callbacks, cancellation, deadline, process cleanup을 구현한다. exact SDK methods는 S01 결과를 사용한다.

완료: 실제 Goose 통합 marker가 작동하고 비용 발생 테스트는 opt-in이다. fake는 기본 unit test에서 사용한다. 실제 Goose 미설치 시 성공이 아니라 명시적 skip/NOT_RUN이다.

### B04. A2A 최소 수직 기능

선행: B02,B03,S07.

공식 SDK로 역할별 Card, Send/Stream/Get/Cancel 경로를 연결한다. 개발용 저장소를 쓰는 동안은 loopback/가상 데이터/단일 사용자로 제한한다. blocking/non-blocking 의미와 output schema를 검증한다.

완료: 공식 SDK client가 실제 Goose를 통해 두 역할의 결과를 받고, 세션을 계속 이어갈 수 있다. M1의 메모리 저장 경로는 개발 전용임을 표시한다. 이 단계에서 대량 사용자·Pod failover를 주장하지 않는다.

## 4. 영속·다중 사용자 — M2

| ID | 작업 | 선행 | 산출물 | 완료 조건 |
|---|---|---|---|---|
| B05 | DB 모델·migration·admission | B04 | SQL migration, store 함수, idempotency | 중복 접수/Context 경쟁/권한 query 테스트 통과 |
| B06 | 분리 Worker·queue·lease | B05 | claim/heartbeat/fencing, attempt | API와 Worker가 별도 프로세스, lease 상실 commit 거부 |
| B07 | Object Storage와 checkpoint | B06,S05 | upload/restore/GC, manifest | 새 Worker에서 대화·스킬·출처 유지, 손상 시 fail closed |
| B08 | DB-backed 이벤트·스트리밍 | B05,B06 | event log, snapshot/watermark, API fan-out | API 재시작 후 조회/재구독; 다른 stream에 영향 없음 |
| B09 | 취소·retry·commit 경합 | B06~B08 | 상태 전이 테스트, retry classifier | cancel/success 한 번만 확정, read-only만 자동 재시도 |
| B10 | OIDC·tenant·도구 권한 경계 | B05,S03,S08 | identity adapter, access tests | 모든 API와 도구에서 cross-user 접근 거부 |
| B11 | quota·모델 slot·fairness | B06,S06,S08 | DB reservations, limits, metrics | 경쟁 요청에도 상한 유지, batch가 interactive를 독점하지 않음 |

B05부터 memory TaskStore를 운영 default로 남기지 않는다. B10이 끝나기 전에는 외부 다중 사용자 접근과 실제 민감 데이터를 허용하지 않는다.

B07에서 import/restore를 새로 구현할 경우 Goose 저장 schema를 역공학으로 무심코 수정하지 않는다. 검증된 공식 경로 또는 일관된 DB snapshot과 동일 runtime version을 사용한다. 저장 format 변경은 migration/compatibility test가 필요하다.

## 5. Kubernetes와 출시 — M3

### B12. OCI 이미지·Helm·배포 계약

선행: M2 핵심 기능, S01 image compatibility.

API/Worker 이미지, external PostgreSQL/Object Storage 설정, Secret references, HTTPRoute, securityContext, resources, probe, migration Job, NetworkPolicy를 작성한다. 이미지는 digest로 pin한다.

완료: `helm lint`, 렌더링 검사, disposable namespace smoke test. 설치하지 않은 Envoy/KEDA CRD를 있다고 가정하지 않는다. 운영 cluster 적용은 별도 승인 대상이다.

### B13. KEDA·drain·안전한 축소

선행: B12,B07,B09,B11.

pool별 workload metric, min/max replicas, stabilization, drain, termination을 구현한다. scale-to-zero는 checkpoint 검증 이후에만 검토한다.

완료: scale-up뿐 아니라 busy Worker scale-down, rolling update, node loss를 시험한다. PDB를 job durability로 잘못 사용하지 않는다.

### B14. 부하·장애·보안 회귀

선행: B12,B13.

[08](08_TEST_AND_RELEASE_GATES.md)의 테스트를 자동화하고 fake와 실제 provider 부하 결과를 구분해 보고한다. peak rate, p95 queue time, success/cancel, 모델 포화, DB/Object Storage 부하를 기록한다.

완료: 모든 필수 테스트에 PASS 근거 또는 출시 차단 사유가 있다. 확인 안 된 항목을 표에서 지우거나 임계값을 조용히 낮추지 않는다.

### B15. 운영 문서·release gate

선행: B14.

실제 환경의 SLO, retention, credential rotation, backup/restore, model/skill/image rollout/rollback을 런북에 반영한다. dependency lock, 이미지 SBOM/취약점 점검 결과, 최소 운영 dashboard를 정리한다.

완료: 운영자가 API·Worker·모델·DB·스킬 오류를 분리해 진단할 수 있고, 정확한 제한사항을 release notes에 기재한다.

## 6. 후속 항목 — M4

| ID | 기능 | 시작 조건 |
|---|---|---|
| F01 | Goose → 원격 A2A 호출 | M3 + allowlisted Agent registry·권한·depth/budget 제한 |
| F02 | 장기 입력/쓰기 승인 | 영속 approval intent·중복 방지·권한 재검증 설계 |
| F03 | 임의 Python/Shell sandbox | 별도 격리 실행 서비스와 네트워크/파일 정책 |
| F04 | Pod당 여러 Goose 프로세스 | RSS·격리·캐시·자격증명 수명 검증 및 실측 이득 |

F01은 별도 A2A client MCP bridge로 시작할 수 있지만 long-running Task·cancel·artifact 상태를 단순 tool timeout으로 없애지 않는다. 호출 chain/depth/time budget과 순환 위임 방지를 넣는다.

## 7. 작업 완료 템플릿

```text
ID / 목표:
선행 검증:
구현 파일:
테스트 명령:
PASS / FAIL / NOT_RUN:
실제 서비스로 검증했는가:
보안·호환성 제약:
다음 작업:
```

PR/commit 크기는 이해 가능한 하나의 기능으로 유지한다. 작다는 이유로 멱등성·권한·취소 경계를 다음 단계로 무기한 미루지 않는다.
