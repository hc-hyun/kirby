# 05. 데이터 모델 · 실행권 · 복구

## 1. 영속 데이터의 원칙

PostgreSQL은 Task/Context/실행권/이벤트 상태의 기준이다. Object Storage는 큰 불변 객체를 저장한다. 두 저장소 사이에 원자적 transaction이 있다고 가정하지 않는다.

테이블·열 이름은 **구현할 논리 모델 초안**이다. 실제 migration 파일은 아직 없다. 모든 시각은 DB의 timezone-aware UTC로 저장한다. client 시각으로 lease 만료를 결정하지 않는다.

## 2. 테이블 초안

| 테이블 | 주요 필드/제약 |
|---|---|
| `role_releases` | role_id, version, digest, validated_config, activated_at; id/version 불변 |
| `skill_releases` | skill_id, version, content_digest, archive_digest, object_key, blocked_at |
| `contexts` | id, tenant_id, owner_subject, owner_client, role_id, manifest_json, checkpoint_id, active_task_id, status |
| `tasks` | id, context_id, tenant_id, role_id, state, deadline_at, attempt_no, lease_owner, lease_generation, lease_expires_at, cancel_requested_at, last_event_seq |
| `messages` | tenant_id, caller_key, role_id, message_id, canonical_request_digest, task_id, context_id, body_ref; dedup unique |
| `attempts` | id, task_id, number, worker_id, lease_generation, state, start/end, error_code, provider_request_refs |
| `task_events` | task_id, seq, attempt_id, event_type, public_payload, created_at; unique(task_id,seq) |
| `artifacts` | id, task_id, attempt_id, object_key, digest, media_type, byte_size, committed, expires_at |
| `checkpoints` | id, context_id, task_id, attempt_id, object_key, digest, goose_version, manifest_digest, format_version, created_at |
| `capacity_slots` | model_pool, slot_id, lease_owner, task_id, lease_generation, lease_expires_at |

단순 모델이라면 일부 release metadata를 JSONB로 묶을 수 있다. 테이블 수를 맞추려고 기능을 늘리지 않는다. 반대로 필요한 unique/index/ownership 조건을 application convention만으로 생략하지 않는다.

## 3. 제약과 인덱스

- message dedup 키는 `tenant + subject/client 호출자 범위 + role + messageId`다. raw token은 키로 사용하지 않는다.
- 동일 dedup 키 + 다른 canonical payload는 충돌 오류다. response mode처럼 의미를 바꾸지 않는 transport 옵션과 실제 message body를 구분해 canonical 규칙을 테스트한다.
- 동일 Context에 비종료 Task 하나를 partial unique index 또는 동등한 DB transaction으로 보장한다. `QUEUED`, `RETRY_WAIT`, `COMMITTING`, `CANCEL_REQUESTED`, 사용 시 `WAITING_INPUT`도 포함한다.
- `messages`가 별도인 이유는 추가 입력 때 여러 messageId가 하나의 비종료 Task에 연결될 수 있기 때문이다.
- query는 tenant/owner/role 조건을 항상 포함한다. 서버가 만든 UUID만으로 접근 권한을 대신하지 않는다.
- claim용 index는 pool/state/eligible_at/created_at를 실제 query plan에 맞게 설계한다.
- 이벤트 순서는 Task row에서 next sequence를 발급하는 짧은 transaction으로 보장한다. `MAX(seq)+1` 경쟁을 만들지 않는다.

## 4. 요청 접수 transaction

1. 중복 키 확인/예약과 Role/Context 권한 검사를 한다.
2. Context의 기존 manifest를 사용하거나 새로운 manifest를 저장한다.
3. 비종료 Task 제약, 사용자 동시성·대기량 상한을 확인한다.
4. Message/Task/초기 Event를 함께 저장하고 commit한다.

동시 API 요청에서 `SELECT count(*)`만 보고 quota를 판단하면 상한을 넘을 수 있다. 필요한 quota row를 잠그거나 slot/예약 테이블을 사용해 원자적으로 확보한다. 중복 요청은 기존 결과/Task ID를 반환하며 새로운 Context나 Goose 세션을 만들지 않는다.

## 5. claim · lease · fencing

Worker는 대상 pool의 적격 Task를 짧은 transaction에서 고르고, Task lease와 모델 slot을 함께 획득한다. 모델 slot이 없으면 Task를 claim한 채 오랫동안 기다리지 말고 transaction을 되돌리거나 다음 실행 시각을 예약한다.

PostgreSQL의 `FOR UPDATE SKIP LOCKED`는 큐 소비자의 경합을 줄이는 선택지다. 작업 본체는 transaction 밖에서 수행한다. [SRC-11]

모든 결과·heartbeat·checkpoint pointer 변경은 아래 조건을 만족해야 한다.

```text
현재 lease_owner가 나인가?
현재 lease_generation이 나의 값과 같은가?
DB 기준 lease가 아직 유효한가?
Task 상태와 cancel_requested_at가 해당 전이를 허용하는가?
```

조건부 UPDATE가 0행이면 성공으로 간주하지 않고 소유권 상실을 처리한다. heartbeat 주기는 lease TTL보다 충분히 짧게 두되 GC/network pause를 측정해 결정한다. 초기값 예시는 10초 heartbeat/60초 lease이며 검증된 운영값이 아니다.

**lease 만료는 이전 프로세스가 죽었다는 증거가 아니다.** 이전 Worker는 연결 복구 후 소유권을 재확인해야 한다. 비밀을 담은 원격 도구 호출은 정책 게이트에서도 단기 실행권을 검증하는 방향으로 설계한다. DB fencing만으로 이미 전송된 외부 요청을 취소할 수는 없다.

## 6. 체크포인트의 내용

```text
checkpoint/
  manifest.json             # 형식·Goose·스킬·모델 설정 digest
  session.native            # 검증한 export 또는 일관된 DB backup
  workspace-manifest.json   # 유지해야 하는 파일만
  workspace/                # 승인된 상태 파일
```

Goose의 로컬 세션 DB와 session export 기능은 문서에 있다. 그러나 **export가 있다는 사실과 ACP session/load를 통해 새 Pod에서 복원 가능하다는 사실은 별도**다. JSON import 방법·session ID 변화·절대 경로·도구 설정을 실제로 확인한다. [SRC-03][SRC-16]

우선순위는 검증된 native export/import → 정지 또는 일관된 SQLite backup → 제한된 pinned-worker pilot이다. 실행 중인 `.db` 파일 하나만 복사하지 않는다. SQLite의 backup API 등 일관된 방법을 사용한다. [SRC-12]

checkpoint에는 원문 토큰, SDK keyring, 환경 전체, debug log 전체를 넣지 않는다. Goose 세션 저장이 도구 연결 metadata에 secret을 포함하는지 검사하고, 안전하게 분리·재바인딩하지 못하면 공유 서비스 출시를 차단한다.

## 7. 결과 확정 순서

1. Goose 턴 종료와 결과 schema를 확인한다.
2. 승인된 결과 파일을 불변 key에 업로드하고 digest/size를 확인한다.
3. 체크포인트를 생성·업로드하고 복원 metadata를 검사한다.
4. DB에서 Task/Context를 잠그고 lease generation, 취소 상태, 이전 checkpoint version을 검사한다.
5. Artifact 참조, 새 Context checkpoint, Task 성공, final Event를 한 transaction으로 확정한다.
6. API가 DB의 확정 결과를 전송한다.

Object Storage 업로드 후 DB commit 실패 시 객체는 orphan이다. 참조되지 않는 오래된 객체를 유예기간 뒤 청소한다. DB commit 후 응답 연결이 끊겼다면 같은 Task의 조회 결과를 돌려주고 다시 실행하지 않는다.

결과가 외부로 일부 스트리밍되었더라도 5번 전까지는 provisional이다. checkpoint 저장 실패가 있으면 계속 대화 가능한 성공으로 표시하지 않는다. 감사 결과에는 "업무 실행은 종료됐으나 저장 실패" 원인을 구분한다.

## 8. 재시도 정책

| 분류 | 정책 |
|---|---|
| admission/권한/스키마 오류 | 자동 재시도 없음 |
| 실행 시작 전 일시 장애 | 제한적 재시도 |
| 검증된 read-only 도구 작업의 중단 | 마지막 확정 checkpoint에서 새 attempt, budget 재검사 |
| LLM timeout/429 | provider request 생존 여부 고려, 제한 backoff |
| 쓰기 결과 불명확 | 자동 재실행 금지, 수동 확인/후속 상태 조회 |
| checksum·checkpoint 호환 오류 | 격리하고 실패; 비어 있는 세션으로 대체 금지 |

새 attempt는 별도 실행 디렉터리와 artifact namespace를 갖는다. 실패한 시도의 일부 세션 DB를 정상 checkpoint로 덮어쓰지 않는다. 재시도마다 입력을 기존 이력에 이중 추가하지 않는지 검증한다.

retry exhaustion 후 외부 Task를 FAILED로 확정한다. 완료된 Task를 다시 활성화하지 않는다.

## 9. 재연결·알림

PostgreSQL notification은 "새 이벤트가 있으니 읽어라"는 힌트만 전송한다. 본문은 `task_events`에 저장한다. bounded polling fallback을 둔다. DB connection 하나를 사용자별 SSE 연결마다 영구 점유하지 않도록 fan-out reader와 제한된 pool을 설계한다.

주기적 delta 배치의 목표 초기값은 200ms 또는 4KiB 중 먼저 도달하는 쪽이다. 이것은 조정값이다. 전체 토큰을 영속 보관할 의무와 최종 결과 영속성은 분리한다.

## 10. 보존과 삭제

개발 기본값 후보: 상세 이벤트 7일, 결과/세션 30일, 감사·중복 방지 tombstone 90일. **실제 개인정보·사내 보존 규정에 따라 승인 전 조정해야 한다.** 정책이 설정되지 않은 운영 배포는 경고 또는 실패시킨다.

본문 삭제와 dedup tombstone 삭제를 분리한다. 저장 보존기간이 지난 messageId 재전송에 어떤 응답을 할지 문서화한다. 만료 후 영구 exactly-once를 주장하지 않는다. skill/model/image/checkpoint 참조가 남아 있는 release를 GC하지 않는다.

## 11. 복원 미지원 시 제한 모드

S05 검증이 실패하면 session ownership을 고정한 pilot만 허용한다. 고정 Worker/PVC는 컨텍스트와 명시적으로 연결하고 장애 상태를 드러낸다. RWO 접근 모드만으로 writer fencing이 완료됐다고 간주하지 않는다.

이 모드에서는 임의 Worker 이동·scale-to-zero·범용 KEDA 확장을 켜지 않는다. M2/M3 전체 복구 조건은 미충족으로 남긴다. 마치 아무 상태도 없는 새 대화로 복구한 것을 성공적인 세션 복원이라고 표시하지 않는다.

참고: [출처](SOURCES.md), [보안·배포](06_SECURITY_AND_KUBERNETES.md), [테스트](08_TEST_AND_RELEASE_GATES.md).
