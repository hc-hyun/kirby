# 개발 상태 — 다음 Codex 세션의 시작점

**마지막 문서 갱신:** 2026-09-05

## 현재 상태

- 계획서·작업 지침·예제 설정 작성 완료.
- 공식 문서에서 기능과 프로토콜 경계를 확인했으나, 실행 호환성은 검증하지 않음.
- 서버·Worker·DB migration·Helm·런타임 테스트는 아직 구현되지 않음.
- Goose/SDK의 선택 버전·이미지 digest·실제 사내 endpoint는 미확정.
- 패키지 내부 링크·JSON/YAML 형식·예제 스키마 검사는 `PACKAGE_QA.md`에 기록됨. 이것은 실제 시스템 테스트가 아님.

## 마일스톤

| 단계 | 상태 | 완료 근거 |
|---|---|---|
| B00 저장소·개발 환경 | NOT_STARTED | 없음 |
| M0 호환성·보안 경계 | NOT_STARTED | 없음 |
| M1 단일 사용자 A2A 수직 기능 | NOT_STARTED | 없음 |
| M2 분산 서빙·다중 사용자·복구 | NOT_STARTED | 없음 |
| M3 Kubernetes·부하·운영 게이트 | NOT_STARTED | 없음 |
| M4 후속 기능 | DEFERRED | 범위 밖 |

## 다음 작업

`B00` 수행 후 `S01`부터 시작. 자세한 순서는 [백로그](docs/07_IMPLEMENTATION_BACKLOG.md)를 따른다.

## 환경에서 확인할 사항

| 항목 | 현재 값 |
|---|---|
| 기존 소스 저장소와 사용자 변경 | 확인 필요 |
| Goose binary/image | 확인 필요 |
| A2A SDK / ACP SDK 정확한 버전 | 확인 필요 |
| 실제 model profile / LLM Gateway | 논리 이름만 정의; endpoint·모델 ID 확인 필요 |
| 테스트 PostgreSQL | 확인 필요 |
| S3 호환 Object Storage | 사용 가능 여부 확인 필요; NFS와 동일시하지 않음 |
| 사내 OIDC issuer / audience / 권한 매핑 | 확인 필요 |
| MCP 사용자별 권한 전달 방식 | 확인 필요 |
| Kubernetes / Envoy / KEDA 설치 버전 | 확인 필요 |

## 작업 기록

| 날짜 | 작업 ID | 상태 | 변경 파일·테스트·근거·다음 작업 |
|---|---|---|---|
| 2026-09-05 | PLAN | DONE | 개발 인계 패키지 작성. 실행 개발 미착수. |

## 설계 변경

새로운 결정은 `docs/11_DECISION_LOG.md`에 기록하고, 관련 예제·스키마·테스트를 함께 수정한다. 이 표에서만 설계를 바꾸지 않는다.
